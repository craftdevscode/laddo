<?php
/**
 * Use namespace to avoid conflict
 */
namespace Listy\PostType;

/**
 * Header footer
 * @package header footer megamenu postype
 */
class HeaderFooter {

    private static $_instance = null;


    public static function instance() {

        if ( is_null( self::$_instance ) ) {
            self::$_instance = new self();
        }
        return self::$_instance;

    }

    public function __construct() {
        add_action( 'plugins_loaded', [ $this, 'on_plugins_loaded' ] );
    }

    public function on_plugins_loaded() {
        add_action( 'admin_menu', [$this, 'listy_core_header_footer_menu'] );
        add_action( 'init', [$this, 'register_post_type'] );
    }

    public function listy_core_header_footer_menu() {
        add_menu_page(
            'Listy Header Footer',
            'Header Footer',
            'read',
            'listy-header-footer',
            '', // Callback, leave empty
            'dashicons-feedback',
            14 // Position
        );
    }

    private function postype_lable($singular, $plural) {
        $labels = array(
            'name'                  => _x( $plural, 'Post type general name', 'listy-core' ),
            'singular_name'         => _x( $singular, 'Post type singular name', 'listy-core' ),
            'menu_name'             => _x( $plural, 'Admin Menu text', 'listy-core' ),
            'name_admin_bar'        => _x( $singular, 'Add New on Toolbar', 'listy-core' ),
            'add_new'               => __( 'Add New', 'listy-core' ),
            'add_new_item'          => __( 'Add New '.$singular, 'listy-core' ),
            'new_item'              => __( 'New '.$singular, 'listy-core' ),
            'edit_item'             => __( 'Edit '.$singular, 'listy-core' ),
            'view_item'             => __( 'View '.$singular, 'listy-core' ),
            'all_items'             => __( 'All '.$plural, 'listy-core' ),
            'search_items'          => __( 'Search '.$plural, 'listy-core' ),
            'parent_item_colon'     => __( 'Parent '.$plural.':', 'listy-core' ),
            'not_found'             => __( 'No '.$plural.' found.', 'listy-core' ),
            'not_found_in_trash'    => __( 'No '.$plural.' found in Trash.', 'listy-core' ),
            'featured_image'        => _x( $singular.' Cover Image', 'Overrides the “Featured Image” phrase for this post type. Added in 4.3', 'listy-core' ),
            'set_featured_image'    => _x( 'Set cover image', 'Overrides the “Set featured image” phrase for this post type. Added in 4.3', 'listy-core' ),
            'remove_featured_image' => _x( 'Remove cover image', 'Overrides the “Remove featured image” phrase for this post type. Added in 4.3', 'listy-core' ),
            'use_featured_image'    => _x( 'Use as cover image', 'Overrides the “Use as featured image” phrase for this post type. Added in 4.3', 'listy-core' ),
            'archives'              => _x( $singular.' archives', 'The post type archive label used in nav menus. Default “Post Archives”. Added in 4.4', 'listy-core' ),
            'insert_into_item'      => _x( 'Insert into '.$singular, 'Overrides the “Insert into post”/”Insert into page” phrase (used when inserting media into a post). Added in 4.4', 'listy-core' ),
            'uploaded_to_this_item' => _x( 'Uploaded to this '.$singular, 'Overrides the “Uploaded to this post”/”Uploaded to this page” phrase (used when viewing media attached to a post). Added in 4.4', 'listy-core' ),
            'filter_items_list'     => _x( 'Filter '.$plural.' list', 'Screen reader text for the filter links heading on the post type listing screen. Default “Filter posts list”/”Filter pages list”. Added in 4.4', 'listy-core' ),
            'items_list_navigation' => _x( $plural.' list navigation', 'Screen reader text for the pagination heading on the post type listing screen. Default “Posts list navigation”/”Pages list navigation”. Added in 4.4', 'listy-core' ),
            'items_list'            => _x( $plural.' list', 'Screen reader text for the items list heading on the post type listing screen. Default “Posts list”/”Pages list”. Added in 4.4', 'listy-core' ),
        );
        return $labels;
    }
	
    public function post_type($singular, $plural, $post_type_name, $slug, $supports=[]) {
        $args = array(
            'labels'             => $this->postype_lable($singular, $plural),
            'description'        => $post_type_name.' custom post type.',
            'public'             => true,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => 'listy-header-footer',
            'query_var'          => true,
            'rewrite'            => array( 'slug' =>  $slug ),
            'capability_type'    => 'post',
            'has_archive'        => true,
            'hierarchical'       => false,
            'menu_position'      => 21,
            'supports'           => ['title', 'elementor'],
            'show_in_rest'       => true
        );

        return $args;
    }

    public function register_post_type() {
        register_post_type( 'listy-mega-menu', $this->post_type('Mega Menu', 'Mega Menus', 'listy-mega-menu', 'listy-mega-menu') );
        register_post_type( 'listy-header', $this->post_type('Header', 'Headers', 'listy-header', 'listy-header') );
        register_post_type( 'listy-footer', $this->post_type('Footer', 'Footers', 'listy-footer', 'listy-footer') );
    }

}

new HeaderFooter();