<?php


add_filter('elementor/controls/animations/additional_animations', 'my_fun');

function my_fun($get_animation) {


    $animations = [

        'Fading' => [
            //'fadeIn' => 'Fade In',
            '' => 'Fade In Down',
            'fadeInLeft' => 'Fade In Left',
            'fadeInRight' => 'Fade In Right',
            'fadeInUp' => 'Fade In Up',
        ],
    ];


    return array_merge( $get_animation, $animations );


}

