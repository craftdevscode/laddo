<?php
/**
 * Lising inventory ajax request
 */
class Listy_Listing_inventory {

    public function __construct()
    {

        // Auction Filter
        add_action('wp_ajax_listing_inventory', [$this, 'listing_inventory_callback']);
        add_action('wp_ajax_nopriv_listing_inventory', [$this, 'listing_inventory_callback']);
        
        // Advance Search
        add_action('wp_ajax_advance_search', [$this, 'advance_search_callback']);
        add_action('wp_ajax_nopriv_advance_search', [$this, 'advance_search_callback']);
    }

    /**
     * Auction Filter
     */
    public function listing_inventory_callback() {

        // wp_send_json_error([
        //     'error'   => true,
        //     'message' => esc_html__('Couldn\'t found any data', 'load-more-ajax-lite')
        // ]);
        $order          = !empty($_POST['order']) ? sanitize_text_field($_POST['order']) : '';
        $post_per_page  = !empty($_POST['per_page']) ? sanitize_text_field($_POST['per_page']) : '';
        $servicesType   = !empty($_POST['service_type']) ? sanitize_text_field($_POST['service_type']) : '';
        $location       = !empty($_POST['location']) ? sanitize_text_field($_POST['location']) : '';
        $current_time   = !empty($_POST['current_time']) ? sanitize_text_field($_POST['current_time']) : '';

        // current_time('H:i');
        $paged      = (get_query_var('paged')) ? get_query_var('paged') : 1;
        $args['suppress_filters'] = true;
        $args['post_type']        = 'listing';
        $args['posts_per_page']   = $post_per_page;
        // $args['paged'] = $order;

        if (!empty( $servicesType || $location )) {
            $serviceTypeCat = !empty($servicesType) ? ['taxonomy' => 'listing_cat', 'field' => 'slug', 'terms' => $servicesType ]  : '';
            $locationTaxo   = !empty($location) ? ['taxonomy' => 'listing_city', 'field' => 'slug', 'terms' => $location ] : '';
            $args['tax_query'] = [
                'relation' => 'AND',
                $serviceTypeCat, $locationTaxo
            ];
        }

        if( !empty($current_time) ){
            $openTime       = ['key' => 'open_time', 'value' => $current_time, 'compare' => '<=', 'type' => 'TIME' ];
            $ClosingTime    = ['key' => 'close_time', 'value' => $current_time, 'compare' => '>=', 'type' => 'TIME' ];
            $args['meta_query'] = array(
                'relation' => 'AND',
                $openTime,
                $ClosingTime
            );
        }

        $query = new \WP_Query($args);

        $postdata = [];
        if( !empty($servicesType ) ){
            $postdata['service_ty'] = $servicesType;
        }
        if (!empty($location)) {
            $postdata['location'] = $location;
        }
        
        $postdata['max_page'] = $query->max_num_pages;
        

        if ($query->have_posts()) :
            while ($query->have_posts()) : $query->the_post();
                global $post;
                $user_local_time = date_i18n('H:i', current_time('timestamp'));
                $lat    = get_post_meta( get_the_ID(), 'location_lat', true );
                $long   = get_post_meta( get_the_ID(), 'location_log', true );
                $open_time  = get_post_meta( get_the_ID(), 'open_time', true );
                $close_time = get_post_meta( get_the_ID(), 'close_time', true );
                $open_close_label = $user_local_time > $open_time && $user_local_time < $close_time ? __('Open','listy-core') : __('Close', 'listy-core');
                $open_close_time  = $user_local_time > $open_time && $user_local_time < $close_time ? __('Closed ', 'listy-core') . date('h:i a', strtotime($close_time)) : __('Opens ', 'listy-core') . date('h:i a', strtotime($open_time));


                $postdata['posts'][] = [
                    'id'        => get_the_ID(),
                    'permalink' => get_the_permalink(), 
                    'title'     => get_the_title(),
                    'thumb'     => get_the_post_thumbnail_url(),
                    'address'   => get_post_meta(get_the_ID(), 'location_address', true ),
                    'website'   => get_post_meta(get_the_ID(), 'website', true ),
                    'phone'     => get_post_meta(get_the_ID(), 'phone_number', true ),
                    'currency'  => get_post_meta(get_the_ID(), 'currency_text', true ),
                    'open_close'=> $open_close_label,
                    'open_close_time'=> $open_close_time,
                    'position'  => [
                        'lat'       => floatval($lat),
                        'lng'       => floatval($long)
                    ]
                ];

            endwhile;
            wp_reset_postdata();
        endif;
        $postdata['paged'] = $order + 1;
        $postdata['limit'] = $post_per_page;
   
        wp_send_json_success($postdata);
    }


    /**
     * Advance Search callback
     */
    public function advance_search_callback() {

        $location = isset($_POST['location']) ? sanitize_text_field($_POST['location']) : '';

        $args['suppress_filters'] = true;
        $args['post_type']        = 'listing';
        $args['posts_per_page']   = -1;

        if (!empty($location)) {
            $args['tax_query'] = [
                ['taxonomy' => 'listing_cat', 'field' => 'slug', 'terms' => $location]
            ];
        }

        $postslist  = get_posts($args);
        $locations  = array();
        foreach ($postslist as $key => $item) {
            $locations_array = get_the_terms($item->ID, 'listing_city');
            foreach ($locations_array as $single_location) {
                $locations[$key] = $single_location->name;
            }
        }

        $postdata = [];

        if( ! empty($location) ){
            $postdata['location'] = $locations;
        }

        wp_send_json_success($postdata);
    }

}

$obj = new Listy_Listing_inventory();
