<?php
if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

/**
 * name: Listy_Core_Enqueue_Scripts | Class
 * Enqueue Scripts
 */
class Listy_Core_Enqueue_Scripts {

	private static $_instance = null;

	public function __construct() {
		add_action( 'plugins_loaded', [ $this, 'on_plugins_loaded' ] );
	}

	public static function instance() {

		if ( is_null( self::$_instance ) ) {
			self::$_instance = new self();
		}

		return self::$_instance;

	}

	public function on_plugins_loaded() {
		add_action( 'init', [ $this, 'register_scripts' ] );
	}

	public function register_scripts() {

		// Register Widget Style's
		add_action( 'elementor/frontend/before_enqueue_styles', [ $this, 'elementor_register_widget_styles' ] );
		add_action( 'elementor/editor/before_enqueue_styles', [ $this, 'elementor_register_widget_styles' ] );

		// Register Widget Script's
		add_action( 'elementor/editor/before_enqueue_scripts', [ $this, 'elementor_register_widget_scripts' ] );
		add_action( 'elementor/frontend/after_register_scripts', [ $this, 'elementor_register_widget_scripts' ] );

		// Register Elementor Preview Editor Script's
		add_action( 'elementor/editor/after_enqueue_scripts', [ $this, 'enqueue_elementor_scripts' ] );
		add_action( 'elementor/frontend/after_enqueue_scripts', [ $this, 'enqueue_elementor_scripts' ] );

		// Register Elementor Preview Editor Style's
		add_action( 'elementor/editor/before_enqueue_scripts', [ $this, 'enqueue_elementor_editor_styles' ] );

		// Enqueue Scripts
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_scripts' ] );

	}

	/**
	 * Register Widget Scripts
	 *
	 * Register custom style required to run Listy Core.
	 *
	 * @access public
	 */
	public function elementor_register_widget_styles() {

		/**
		 * Register Style's
		 */
		wp_register_style( 'slick-theme', LISTY_CORE_DIR_VEND . '/slick/css/slick-theme.css' );
		wp_register_style( 'slick', LISTY_CORE_DIR_VEND . '/slick/css/slick.css' );
		wp_register_style( 'fancybox', LISTY_CORE_DIR_VEND . '/fancybox/fancybox.min.css' );

	}


	/**
	 * Register Widget Scripts
	 *
	 * Register custom scripts required to run Listy Core.
	 *
	 * @access public
	 */
	public function elementor_register_widget_scripts() {

		wp_register_script( 'ajax-chimp', LISTY_CORE_DIR_VEND . '/ajax/ajax-chimp.js', 'jquery', LISTY_CORE_VERSION, true );
		wp_register_script( 'jquery-ui', LISTY_CORE_DIR_VEND . '/jquery-ui/jquery-ui.min.js', 'jquery', '1.12.1', true );
		wp_register_script( 'slick', LISTY_CORE_DIR_VEND . '/slick/js/slick.min.js', [ 'jquery' ], LISTY_CORE_VERSION, true );
		wp_register_script( 'fancybox', LISTY_CORE_DIR_VEND . '/fancybox/fancybox.min.js', [ 'jquery' ], '3.5.7', true );

	}

	/**
	 * Register Widget Styles
	 *
	 * Register custom styles required to run Listy Core.
	 *
	 * @access public
	 */

	public function enqueue_elementor_scripts() {

		wp_enqueue_script( 'listy-elementor', LISTY_CORE_DIR_JS . '/listy-elementor.js', [
			'jquery',
			'elementor-frontend'
		], '1.0', true );

	}

	public function enqueue_elementor_editor_styles() {
		wp_enqueue_style( 'listy-elementor-editor', LISTY_CORE_DIR_CSS . '/elementor-editor.css' );
	}


	public function enqueue_scripts() {

		/**
		 * Enqueue Style's
		 */
		wp_enqueue_style( 'listy-core-custom', LISTY_CORE_DIR_CSS . '/custom.css' );


		/**
		 * Enqueue Script's
		 */
		wp_enqueue_script( 'listy-map-api', 'https://maps.googleapis.com/maps/api/js?key=AIzaSyDtXgOn-M2dOXlM4Ee-pUHSnbRyr21zN-M', '', '1.0', true );
		wp_enqueue_script( 'listy-listing-inventory', LISTY_CORE_DIR_JS . '/listy-listing-inventory.js', array( 'jquery' ), '1.0', true );
		wp_localize_script( 'listy-listing-inventory', 'inventory_listing', array(
			'ajax_url' => admin_url( 'admin-ajax.php' )
		) );


	}

}

Listy_Core_Enqueue_Scripts::instance();