<?php
/**
 * Listy theme helper functions and resources
 */

class Listy_Core_Directory_Helper {
    /**
     * Hold an instance of Listy_Core_Directory_Helper class.
     * @var Listy_Core_Directory_Helper
     */
    protected static $instance = null;

    /**
     * Main Listy_Core_Directory_Helper instance.
     * @return Listy_Core_Directory_Helper - Main instance.
     */
    public static function instance() {

        if (null == self::$instance) {
            self::$instance = new Listy_Core_Directory_Helper();
        }

        return self::$instance;
    }




}


/**
 * Instance of Helper_Core_Helper_Class class
 */
function Listy_Core_Directory_Helper() {
    return Listy_Core_Directory_Helper::instance();
}