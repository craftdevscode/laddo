<?php
/**
 * Add Custom Image Size
 */
add_image_size( 'listy_70x70', 70, 70, true ); // Recent Post Sidebar
add_image_size( 'listy_510x440', 510, 440, true ); // Blog 01 thumb
add_image_size( 'listy_510x310', 510, 310, true ); // Blog 02, 03 thumb
add_image_size( 'listy_750x470', 750, 470, true ); // Blog 04 thumb
add_image_size( 'listy_550x460', 550, 460, true ); // Listing Locations 01 thumb
add_image_size( 'listy_234x234', 234, 234, true ); // Listing Locations 02 thumb
add_image_size( 'listy_310x190', 310, 190, true ); // Timeline Carousel thumb
add_image_size( 'listy_196x226', 196, 226, true ); // Category 03 thumb
add_image_size( 'listy_636x484', 636, 484, true ); // Category 03 thumb
add_image_size( 'listy_416x227', 416, 227, true ); // Category 03 thumb
add_image_size( 'listy_416x484', 416, 484, true ); // Category 03 thumb


/**
 * Elementor Title tags
 */
function listy_el_title_tags() {
	return [
		'h1'   => 'H1',
		'h2'   => 'H2',
		'h3'   => 'H3',
		'h4'   => 'H4',
		'h5'   => 'H5',
		'h6'   => 'H6',
		'div'  => 'div',
		'span' => 'span',
		'p'    => 'p',
	];
}


/**
 * Elementor Ratting
 */
function listy_el_ratting_options() {
	return [
		'1' => '1 Star',
		'2' => '2 Star',
		'3' => '3 Star',
		'4' => '4 Star',
		'5' => '5 Star',
	];
}


/**
 * Get Default Image Elementor
 *
 * @param $settins_key
 * @param string $class
 * @param string $alt
 */
function listy_el_image( $settings_key = '', $alt = '', $class = '' ) {
	if ( ! empty( $settings_key['id'] ) ) {
		echo wp_get_attachment_image( $settings_key['id'], 'full', '', array( 'class' => $class ) );
	} elseif ( ! empty( $settings_key['url'] ) && empty( $settings_key['id'] ) ) {
		$class = ! empty( $class ) ? "class='$class'" : '';
		echo "<img src='{$settings_key['url']}' $class alt='$alt'>";
	}
}


/**
 * Event Tab data
 *
 * @param $getCats
 * @param $event_schedule_cats
 *
 * @return array
 */
function return_tab_data( $getCats, $event_schedule_cats ) {
	$y = [];
	foreach ( $getCats as $val ) {

		$t = [];
		foreach ( $event_schedule_cats as $data ) {
			if ( $data['tab_title'] == $val ) {
				$t[] = $data;
			}
		}
		$y[ $val ] = $t;
	}

	return $y;
}

/**
 * @param $settings
 * @param $settings_key
 *
 * @return string
 */
function listy_el_ratting( $settings, $settings_key ) {

	for ( $i = 1; $i <= 5; $i ++ ) {
		if ( $i > $settings[ $settings_key ] ) {
			echo '<a href="#"><i class="icon_star_alt"></i></a>';
		} else {
			echo '<a href="#"><i class="icon_star"></i></a>';
		}
	}

}


function listy_get_el_text_alignment() {

	$choose_alignment = [
		'left'   => [
			'title' => __( 'Left', 'listy-core' ),
			'icon'  => 'eicon-text-align-left',
		],
		'center' => [
			'title' => __( 'Center', 'listy-core' ),
			'icon'  => 'eicon-text-align-center',
		],
		'right'  => [
			'title' => __( 'Right', 'listy-core' ),
			'icon'  => 'eicon-text-align-right',
		],
	];

	return $choose_alignment;

}

// Category array job
function listy_cat_array( $term = 'category' ) {
	$cats      = get_terms( array(
		'taxonomy'   => $term,
		'hide_empty' => true
	) );
	$cat_array = [];
	foreach ( $cats as $cat ) {
		$cat_array[ $cat->slug ] = $cat->name;
	}

	return $cat_array;
}

/**
 *
 * @param String
 * Return Publish Post
 * Posts Count
 */
function listyCore_count_posts() {

	$count_posts  = wp_count_posts( 'job' );
	$total_posts  = $count_posts->publish;
	$default_zero = esc_html__( '0', 'banca' );

	if ( $total_posts == 0 ) {
		$text_post = esc_html__( 'No job available', 'banca' );
	} elseif ( $total_posts <= 9 ) {
		$text_post = $default_zero . $total_posts;
	} elseif ( $total_posts > 9 ) {
		$text_post = $total_posts;
	}

	return $text_post;

}

/**
 * @return float|int
 * Get Category Count
 * Total Category count posts by array
 */
function listy_get_cats_count_all( $term = 'category' ) {

	$cats = get_terms( array(
		'taxonomy'   => $term,
		'hide_empty' => true
	) );

	$cats_count = [];
	foreach ( $cats as $cat ) {
		$cats_count[ $cat->slug ] = $cat->count;
	}

	$total_cats_count = array_sum( $cats_count );

	return $total_cats_count;

}


/**
 * @param $mimes
 * Support SVG Image
 *
 * @return mixed
 */
function listy_mime_types( $mimes ) {
	$mimes['svg'] = 'image/svg+xml';

	return $mimes;
}

add_filter( 'upload_mimes', 'listy_mime_types' );