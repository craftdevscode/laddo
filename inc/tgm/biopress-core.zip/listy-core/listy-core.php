<?php
/**
 * Plugin Name: Listy Core
 * Plugin URI: https://themeforest.net/user/spider-themes/portfolio
 * Description: This plugin adds the core features to the Listy WordPress theme. You must have to install this plugin to get all the features included with the Listy theme.
 * Version: 1.0.0
 * Requires at least: 5.0
 * Tested up to: 5.8
 * Requires PHP: 7.0
 * Author: spider-themes
 * Author URI: https://themeforest.net/user/spider-themes/portfolio
 * Text domain: listy-core
 */

if ( ! defined( 'ABSPATH' ) ) {
	die( '-1' );
}

// Listy Core (short-form - LC) Directories
define( 'LISTY_CORE_VERSION', '1.0.0' );
define( 'LISTY_CORE__FILE__', __FILE__ );
define( 'LISTY_CORE_DIR_PATH', plugin_dir_path( LISTY_CORE__FILE__ ) );
define( 'LISTY_CORE_IMAGES', plugins_url( 'assets/img', __FILE__ ) );
define( 'LISTY_CORE_DIR_CSS', plugins_url( 'assets/css', __FILE__ ) );
define( 'LISTY_CORE_DIR_JS', plugins_url( 'assets/js', __FILE__ ) );
define( 'LISTY_CORE_DIR_VEND', plugins_url( 'assets/vendors', __FILE__ ) );

/**
 * Main instance of Listy_Core.
 *
 * Returns the main instance of Listy_Core to prevent the need to use globals.
 *
 * @return Listy_Core
 * @since  1.0.0
 */
if ( ! class_exists( 'Listy_core' ) ) {

	/**
	 * Main Listy Core Class
	 *
	 * The main class that initiates and runs the Listy Core plugin.
	 *
	 * @since 1.7.0
	 */
	class Listy_core {
		/**
		 * Listy Core Version
		 *
		 * Holds the version of the plugin.
		 *
		 * @since 1.7.0
		 * @since 1.7.1 Moved from property with that name to a constant.
		 *
		 * @var string The plugin version.
		 */
		const VERSION = '1.0.0';

		/**
		 * Minimum Elementor Version
		 *
		 * Holds the minimum Elementor version required to run the plugin.
		 *
		 * @since 1.7.0
		 * @since 1.7.1 Moved from property with that name to a constant.
		 *
		 * @var string Minimum Elementor version required to run the plugin.
		 */
		const MINIMUM_ELEMENTOR_VERSION = '2.6.0';

		/**
		 * Minimum PHP Version
		 *
		 * Holds the minimum PHP version required to run the plugin.
		 *
		 * @since 1.7.0
		 * @since 1.7.1 Moved from property with that name to a constant.
		 *
		 * @var string Minimum PHP version required to run the plugin.
		 */
		const  MINIMUM_PHP_VERSION = '7.0';

		/**
		 * Instance
		 *
		 * Holds a single instance of the `Listy_Core` class.
		 *
		 * @since 1.7.0
		 *
		 * @access private
		 * @static
		 *
		 * @var Listy_Core A single instance of the class.
		 */
		private static $_instance = null;

		/**
		 * Instance
		 *
		 * Ensures only one instance of the class is loaded or can be loaded.
		 *
		 * @return Listy_Core An instance of the class.
		 * @since 1.7.0
		 *
		 * @access public
		 * @static
		 *
		 */
		public static function instance() {
			if ( is_null( self::$_instance ) ) {
				self::$_instance = new self();
			}

			return self::$_instance;
		}

		/**
		 * Clone
		 *
		 * Disable class cloning.
		 *
		 * @return void
		 * @since 1.7.0
		 *
		 * @access protected
		 *
		 */
		public function __clone() {
			// Cloning instances of the class is forbidden
			_doing_it_wrong( __FUNCTION__, esc_html__( 'Cheatin&#8217; huh?', 'listy-core' ), '1.7.0' );
		}

		/**
		 * Wakeup
		 *
		 * Disable unserializing the class.
		 *
		 * @return void
		 * @since 1.7.0
		 *
		 * @access protected
		 *
		 */
		public function __wakeup() {
			// Unserializing instances of the class is forbidden.
			_doing_it_wrong( __FUNCTION__, esc_html__( 'Cheatin&#8217; huh?', 'listy-core' ), '1.7.0' );
		}

		/**
		 * Constructor
		 *
		 * Initialize the Listy Core plugins.
		 *
		 * @since 1.7.0
		 *
		 * @access public
		 */
		public function __construct() {
			$opt = get_option( 'listy_opt' );
			$this->init_hooks();
			$this->core_includes();

			add_filter( 'elementor/icons_manager/additional_tabs', [ $this, 'listy_elegant_icons' ] );
			add_filter( 'elementor/icons_manager/additional_tabs', [ $this, 'listy_line_awesome_icons' ] );
			//self:: generate_custom_font_icons();
		}

		public function listy_elegant_icons( $custom_fonts ) {
			$css_data  = LISTY_DIR_VEND . '/elegant-icon/style.css';
			$json_data = plugins_url( 'assets/fonts/elegant.json', __FILE__ );

			$custom_fonts['elegant_icons'] = [
				'name'          => 'elegant_icons',
				'label'         => esc_html__( 'Elegant Icons', 'listy-core' ),
				'url'           => $css_data,
				'prefix'        => '',
				'displayPrefix' => '',
				'labelIcon'     => 'eicon-text-align-center',
				'ver'           => '',
				'fetchJson'     => $json_data,
				'native'        => true,
			];

			return $custom_fonts;
		}

		public function listy_line_awesome_icons( $custom_fonts ) {

			//jjsdkfsdjfkjskldfje9jask  $css_data  = function_exists( 'listy_setup' ) ?? LISTY_DIR_VEND . '/line-awesome/line-awesome.min.css';
			$css_data  = LISTY_DIR_VEND . '/line-awesome/line-awesome.min.css';
			$json_data = plugins_url( 'assets/fonts/elegant.json', __FILE__ );

			$custom_fonts['line_awesome_icons'] = [
				'name'          => 'line_awesome_icons',
				'label'         => esc_html__( 'Line Awesome Icons', 'listy-core' ),
				'url'           => $css_data,
				'prefix'        => '',
				'displayPrefix' => '',
				'labelIcon'     => 'eicon-text-align-center',
				'ver'           => '',
				'fetchJson'     => $json_data,
				'native'        => true,
			];

			return $custom_fonts;
		}


		public static function generate_custom_font_icons() {
			$css_source = '';
			global $wp_filesystem;
			require_once( ABSPATH . '/wp-admin/includes/file.php' );
			WP_Filesystem();
			$css_file = LISTY_CORE_DIR_PATH . '/assets/fonts/style.css';

			if ( $wp_filesystem->exists( $css_file ) ) {
				$css_source = $wp_filesystem->get_contents( $css_file );
			}

			preg_match_all( "/\.(arrow_.*?):\w*?\s*?{/", $css_source, $matches, PREG_SET_ORDER, 0 );
			$iconList = [];

			foreach ( $matches as $match ) {
				$icon       = str_replace( '', '', $match[1] );
				$icons      = explode( ' ', $icon );
				$iconList[] = current( $icons );
			}

			$icons        = new \stdClass();
			$icons->icons = $iconList;
			$icon_data    = json_encode( $icons );
			$file         = LISTY_CORE_DIR_PATH . '/assets/fonts/elegant.json';
			global $wp_filesystem;
			require_once( ABSPATH . '/wp-admin/includes/file.php' );
			WP_Filesystem();
			if ( $wp_filesystem->exists( $file ) ) {
				$content = $wp_filesystem->put_contents( $file, $icon_data );
			}
		}


		/**
		 * Include Files
		 *
		 * Load core files required to run the plugin.
		 *
		 * @since 1.7.0
		 *
		 * @access public
		 */
		public function core_includes() {

			// Extra functions
			require_once __DIR__ . '/inc/extra.php';

			//Filter Actions
			require_once __DIR__ . '/inc/filter_actions.php';

			//Custom post types
			require_once __DIR__ . '/inc/post-types/class-faq.php';
			require_once __DIR__ . '/inc/post-types/class-job.php';
			require_once __DIR__ . '/inc/post-types/class-header-footer.php';
			require_once __DIR__ . '/inc/post-types/class-listing.php';

			/**
			 * Plugin's Helper Class
			 */
			require_once __DIR__ . '/inc/classes/class-plugin-helper.php';
			require_once __DIR__ . '/inc/classes/class-listing-inventory.php';

			/**
			 * Plugin's Directory Helper Class
			 */
			require_once __DIR__ . '/inc/classes/class-plugin-listing-helper.php';


			/**
			 * plugin's scripts enqueue
			 */
			require_once __DIR__ . '/inc/classes/class-enqueue-scripts.php';


			/**
			 * Register widget area.
			 *
			 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
			 */
			require_once __DIR__ . '/wp-widgets/widgets.php';

		}

		/**
		 * Init Hooks
		 *
		 * Hook into actions and filters.
		 *
		 * @since 1.7.0
		 *
		 * @access private
		 */
		private function init_hooks() {
			add_action( 'init', [ $this, 'i18n' ] );
			add_action( 'plugins_loaded', [ $this, 'init_plugin' ] );
		}

		/**
		 * Load Textdomain
		 *
		 * Load plugin localization files.
		 *
		 * @since 1.7.0
		 *
		 * @access public
		 */
		public function i18n() {
			load_plugin_textdomain( 'listy-core', false, plugin_basename( dirname( __FILE__ ) ) . '/languages' );
		}

		/**
		 * Init Listy Core
		 *
		 * Load the plugin after Elementor (and other plugins) are loaded.
		 *
		 * @since 1.0.0
		 * @since 1.7.0 The logic moved from a standalone function to this class method.
		 *
		 * @access public
		 */
		public function init_plugin() {

			if ( ! did_action( 'elementor/loaded' ) ) {
				add_action( 'admin_notices', [ $this, 'admin_notice_missing_main_plugin' ] );

				return;
			}

			// Check for required Elementor version
			if ( ! version_compare( ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=' ) ) {
				add_action( 'admin_notices', [ $this, 'admin_notice_minimum_elementor_version' ] );

				return;
			}

			// Check for required PHP version
			if ( version_compare( PHP_VERSION, self::MINIMUM_PHP_VERSION, '<' ) ) {
				add_action( 'admin_notices', [ $this, 'admin_notice_minimum_php_version' ] );

				return;
			}

			// Add new Elementor Categories
			add_action( 'elementor/init', [ $this, 'add_elementor_category' ] );

			// Register New Widgets
			add_action( 'elementor/widgets/register', [ $this, 'on_widgets_registered' ] );

		}

		/**
		 * Admin notice
		 *
		 * Warning when the site doesn't have Elementor installed or activated.
		 *
		 * @since 1.1.0
		 * @since 1.7.0 Moved from a standalone function to a class method.
		 *
		 * @access public
		 */
		public function admin_notice_missing_main_plugin() {
			$message = sprintf(
			/* translators: 1: Listy Core 2: Elementor */
				esc_html__( '"%1$s" requires "%2$s" to be installed and activated.', 'listy-core' ),
				'<strong>' . esc_html__( 'Listy core', 'listy-core' ) . '</strong>',
				'<strong>' . esc_html__( 'Elementor', 'listy-core' ) . '</strong>'
			);
			printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
		}

		/**
		 * Admin notice
		 *
		 * Warning when the site doesn't have a minimum required PHP version.
		 *
		 * @since 1.7.0
		 *
		 * @access public
		 */
		public function admin_notice_minimum_php_version() {
			$message = sprintf(
			/* translators: 1: Listy Core 2: PHP 3: Required PHP version */
				esc_html__( '"%1$s" requires "%2$s" version %3$s or greater.', 'listy-core' ),
				'<strong>' . esc_html__( 'Listy Core', 'listy-core' ) . '</strong>',
				'<strong>' . esc_html__( 'PHP', 'listy-core' ) . '</strong>',
				self::MINIMUM_PHP_VERSION
			);
			printf( '<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message );
		}

		/**
		 * Add new Elementor Categories
		 *
		 * Register new widget categories for Listy Core widgets.
		 *
		 * @since 1.0.0
		 * @since 1.7.1 The method moved to this class.
		 *
		 * @access public
		 */
		public function add_elementor_category() {
			\Elementor\Plugin::instance()->elements_manager->add_category( 'listy-elements', [
				'title' => __( 'Listy Elements', 'listy-core' ),
			], 1 );
		}


		/**
		 * Register New Widgets
		 *
		 * Include Listy Core widgets files and register them in Elementor.
		 *
		 * @since 1.0.0
		 * @since 1.7.1 The method moved to this class.
		 *
		 * @access public
		 */
		public function on_widgets_registered() {
			$this->include_widgets();
			$this->register_widgets();
		}

		/**
		 * Include Widgets Files
		 *
		 * Load Listy Core widgets files.
		 *
		 * @since 1.0.0
		 * @since 1.7.1 The method moved to this class.
		 *
		 * @access private
		 */
		private function include_widgets() {

			require_once( __DIR__ . '/widgets/Listy_Blog.php' );
			require_once( __DIR__ . '/widgets/Listy_Locations.php' );
			require_once( __DIR__ . '/widgets/Listy_Category.php' );
			require_once( __DIR__ . '/widgets/Listy_Listing.php' );
			require_once( __DIR__ . '/widgets/Listy_Testimonials.php' );
			require_once( __DIR__ . '/widgets/Listy_Team.php' );
			require_once( __DIR__ . '/widgets/Listy_Video.php' );
			require_once( __DIR__ . '/widgets/Listy_Search_Form.php' );
			require_once( __DIR__ . '/widgets/Listy_Timeline_Carousel.php' );
			require_once( __DIR__ . '/widgets/Listy_Process.php' );
			require_once( __DIR__ . '/widgets/Listy_Pricing_Switcher.php' );
			require_once( __DIR__ . '/widgets/Listy_Faqs.php' );
			require_once( __DIR__ . '/widgets/Listy_Available_Job_Posts.php' );
			require_once( __DIR__ . '/widgets/Listy_Jobs.php' );
			require_once( __DIR__ . '/widgets/Listy_Search_form_job.php' );
			require_once( __DIR__ . '/widgets/Listy_Advance_Search.php' );
			require_once( __DIR__ . '/widgets/Listy_Card.php' );
			require_once( __DIR__ . '/widgets/Listy_Mailchimp.php' );
			require_once( __DIR__ . '/widgets/Listy_Signup.php' );
			require_once( __DIR__ . '/widgets/Listy_Signin.php' );
		}

		/**
		 * Register Widgets
		 *
		 * Register Listy Core widgets.
		 *
		 * @since 1.0.0
		 * @since 1.7.1 The method moved to this class.
		 *
		 * @access private
		 */
		private function register_widgets() {

			\Elementor\Plugin::instance()->widgets_manager->register( new \ListyCore\Widgets\Listy_Blog() );
			\Elementor\Plugin::instance()->widgets_manager->register( new \ListyCore\Widgets\Listy_Locations() );
			\Elementor\Plugin::instance()->widgets_manager->register( new \ListyCore\Widgets\Listy_Category() );
			\Elementor\Plugin::instance()->widgets_manager->register( new \ListyCore\Widgets\Listy_Listing() );
			\Elementor\Plugin::instance()->widgets_manager->register( new \ListyCore\Widgets\Listy_Testimonials() );
			\Elementor\Plugin::instance()->widgets_manager->register( new \ListyCore\Widgets\Listy_Team() );
			\Elementor\Plugin::instance()->widgets_manager->register( new \ListyCore\Widgets\Listy_Video() );
			\Elementor\Plugin::instance()->widgets_manager->register( new \ListyCore\Widgets\Listy_Search_Form() );
			\Elementor\Plugin::instance()->widgets_manager->register( new \ListyCore\Widgets\Listy_Timeline_Carousel() );
			\Elementor\Plugin::instance()->widgets_manager->register( new \ListyCore\Widgets\Listy_Process() );
			\Elementor\Plugin::instance()->widgets_manager->register( new \ListyCore\Widgets\Listy_Pricing_Switcher() );
			\Elementor\Plugin::instance()->widgets_manager->register( new \ListyCore\Widgets\Listy_Faqs() );
			\Elementor\Plugin::instance()->widgets_manager->register( new \ListyCore\Widgets\Listy_Available_Job_Posts() );
			\Elementor\Plugin::instance()->widgets_manager->register( new \ListyCore\Widgets\Listy_Jobs() );
			\Elementor\Plugin::instance()->widgets_manager->register( new \ListyCore\Widgets\Listy_Search_form_job() );
			\Elementor\Plugin::instance()->widgets_manager->register( new \ListyCore\Widgets\Listy_Advance_Search() );
			\Elementor\Plugin::instance()->widgets_manager->register( new \ListyCore\Widgets\Listy_Card() );
			\Elementor\Plugin::instance()->widgets_manager->register( new \ListyCore\Widgets\Listy_Mailchimp() );
			\Elementor\Plugin::instance()->widgets_manager->register( new \ListyCore\Widgets\Listy_Signup() );
			\Elementor\Plugin::instance()->widgets_manager->register( new \ListyCore\Widgets\Listy_Signin() );
		}
	}
}


// Make sure the same function is not loaded twice in free/premium versions.

if ( ! function_exists( 'listy_core_load' ) ) {
	/**
	 * Load Banca Core
	 *
	 * Main instance of Banca_Core.
	 *
	 * @since 1.0.0
	 * @since 1.7.0 The logic moved from this function to a class method.
	 */
	function listy_core_load() {
		return Listy_core::instance();
	}

	// Run Banca Core
	listy_core_load();
}