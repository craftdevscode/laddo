<?php

namespace ListyCore\Widgets;


// Exit if accessed directly
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Image_hover
 * @package ListyCore\Widgets
 */
class Listy_Blog extends \Elementor\Widget_Base {

	public function get_name() {
		return 'listy_blog';
	}

	public function get_title() {
		return __( 'Blog Posts (Listy)', 'listy-core' );
	}

	public function get_icon() {
		return 'eicon-post';
	}

	public function get_categories() {
		return [ 'listy-elements' ];
	}

	/**
	 * Name: register_controls()
	 * Desc: Register controls for these widgets
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	protected function register_controls() {
		$this->elementor_content_control();
		$this->elementor_style_control();
	}


	/**
	 * Name: elementor_content_control()
	 * Desc: Register content
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	public function elementor_content_control() {


		//============================= Layout ================================//
		$this->start_controls_section(
			'select_layout', [
				'label' => __( 'Layout', 'listy-core' ),
			]
		);

		$this->add_control(
			'layout', [
				'label'   => __( 'Layout', 'listy-core' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'1' => __( '01: Blog Grid', 'listy-core' ),
					'2' => __( '02: Blog Grid', 'listy-core' ),
					'3' => __( '03: Blog with Pagination', 'listy-core' ),
					'4' => __( '04: Blog Sticky', 'listy-core' ),
					'5' => __( '05: Blog Category', 'listy-core' ),
				],
				'default' => '1',
			]
		);

		$this->end_controls_section(); //End Layout


		//============================= Filter Options ================================//
		$this->start_controls_section(
			'filter_sec', [
				'label' => __( 'Filter', 'listy-core' ),
			]
		);

		$this->add_control(
			'cats', [
				'label'       => esc_html__( 'Category', 'listy-core' ),
				'description' => esc_html__( 'Display blog by categories', 'listy-core' ),
				'type'        => \Elementor\Controls_Manager::SELECT2,
				'options'     => Listy_Core_Helper()->get_the_categories(),
				'multiple'    => true,
				'label_block' => true,
			]
		);

		$this->add_control(
			'show_count', [
				'label'   => esc_html__( 'Number of Posts to Show', 'listy-core' ),
				'type'    => \Elementor\Controls_Manager::NUMBER,
				'default' => 3
			]
		);

		$this->add_control(
			'order', [
				'label'   => esc_html__( 'Order', 'listy-core' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'ASC'  => 'ASC',
					'DESC' => 'DESC'
				],
				'default' => 'ASC'
			]
		);

		$this->add_control(
			'orderby', [
				'label'   => esc_html__( 'Order By', 'listy-core' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'none'   => 'None',
					'ID'     => 'ID',
					'author' => 'Author',
					'title'  => 'Title',
					'name'   => 'Name (by post slug)',
					'date'   => 'Date',
					'rand'   => 'Random',
				],
				'default' => 'none'
			]
		);

		$this->add_control(
			'title_length', [
				'label' => esc_html__( 'Title Length', 'listy-core' ),
				'type'  => \Elementor\Controls_Manager::NUMBER,
			]
		);

		$this->add_control(
			'excerpt_length', [
				'label'   => esc_html__( 'Excerpt Word Length', 'listy-core' ),
				'type'    => \Elementor\Controls_Manager::NUMBER,
				'default' => 15,
			]
		);

		$this->add_control(
			'exclude', [
				'label'       => esc_html__( 'Exclude Post', 'listy-core' ),
				'description' => esc_html__( 'Enter the portfolio post IDs to hide/exclude. Input the multiple ID with comma separated', 'listy-core' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
			]
		);

		// View Button
		$this->add_control(
			'read_more_btn', [
				'label'       => esc_html__( 'Read More Button', 'banca-core' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => 'Read More',
				'condition'   => [
					'layout' => '4'
				]
			]
		);

		$this->end_controls_section(); //End Filter Options

	}


	/**
	 * Name: elementor_style_control()
	 * Desc: Register style content
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	public function elementor_style_control() {

		$this->start_controls_section(
			'style_sec',
			[
				'label' => esc_html__( 'Content Style', 'textdomain' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'title_heading',
			[
				'label'     => esc_html__( 'Title', 'textdomain' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Color', 'textdomain' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .article-title, .blog-widget .blog-content h5' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .article-title, .blog-widget .blog-content h5',
			]
		);

		$this->add_control(
			'categoris_heading',
			[
				'label'     => esc_html__( 'Categoris', 'textdomain' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control(
			'categoris_color',
			[
				'label'     => esc_html__( 'Color', 'textdomain' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .article-item .left-caption, .blog-widget .blog-content .blog-text' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'categoris_typography',
				'selector' => '{{WRAPPER}} .article-item .left-caption, .blog-widget .blog-content .blog-text',
			]
		);

		$this->add_control(
			'author_heading',
			[
				'label'     => esc_html__( 'Author', 'textdomain' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control(
			'author_color',
			[
				'label'     => esc_html__( 'Color', 'textdomain' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .article-sub-item a, .blog-widget .blog-content .blog-sub-text a' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'author_typography',
				'selector' => '{{WRAPPER}} .article-sub-item a, .blog-widget .blog-content .blog-sub-text a',
			]
		);

		$this->add_control(
			'date_heading',
			[
				'label'     => esc_html__( 'Date', 'textdomain' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control(
			'date_color',
			[
				'label'     => esc_html__( 'Color', 'textdomain' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .article-sub-item .article-date, .article-sub-item .article-date i, .blog-widget .blog-content .blog-sub-text' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'date_typography',
				'selector' => '{{WRAPPER}} .article-sub-item .article-date, .article-sub-item .article-date i, .blog-widget .blog-content .blog-sub-text',
			]
		);

		$this->end_controls_section();

	}


	/**
	 * Name: elementor_render()
	 * Desc: Render widget output on the frontend.
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		extract( $settings ); //Array to variable conversation

		$paged  = get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1;
		$sticky = get_option( 'sticky_posts' );

		$args = [
			'post_type'   => 'post',
			'post_status' => 'publish',
			'paged'       => $paged,
		];

		if ( ! empty( $show_count ) ) {
			$args['posts_per_page'] = $show_count;
		}

		if ( ! empty( $order ) ) {
			$args['order'] = $order;
		}

		if ( ! empty( $orderby ) ) {
			$args['orderby'] = $orderby;
		}

		if ( ! empty( $exclude ) ) {
			$args['post__not_in'] = $exclude;
		}

		if ( ! empty( $cats ) ) {
			$args['tax_query'] = [
				[
					'taxonomy' => 'category',
					'field'    => 'id',
					'terms'    => $cats

				]
			];
		}

		$posts = new \WP_Query( $args );

		//==================== Template Parts =======================//
		include "template/blog/blog-{$settings['layout']}.php";

	}
}