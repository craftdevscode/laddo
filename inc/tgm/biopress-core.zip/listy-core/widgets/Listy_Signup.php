<?php

namespace ListyCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class SignUp
 * @package ListyCore\Widgets
 */
class Listy_Signup extends Widget_Base {

	public function get_name() {
		return 'listy_signup';
	}

	public function get_title() {
		return __( 'Sign Up', 'listy-core' );
	}

	public function get_icon() {
		return 'eicon-person';
	}

	public function get_categories() {
		return [ 'listy-elements' ];
	}

	/**
	 * Name: register_controls()
	 * Desc: Register controls for these widgets
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	protected function register_controls() {
		$this->elementor_content_control();
		$this->elementor_style_control();
	}


	/**
	 * Name: elementor_content_control()
	 * Desc: Register content
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	public function elementor_content_control() {

		//======================== Forms Settings ==========================//
		$this->start_controls_section(
			'form_settings', [
				'label' => __( 'Form Settings', 'listy-core' ),
			]
		);

		//========== Sign In Button
		$this->add_control(
			'btn_label', [
				'label' => esc_html__( 'Sign In Button', 'listy-core' ),
				'type'  => Controls_Manager::HEADING,
			]
		);

		$this->add_control(
			'signin_btn_label', [
				'label'       => esc_html__( 'Button Title', 'listy-core' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => 'Sign In'
			]
		);

		$this->add_control(
			'signin_btn_url', [
				'label'   => esc_html__( 'Button URL', 'listy-core' ),
				'type'    => Controls_Manager::URL,
				'default' => [
					'url' => '#'
				]
			]
		);

		$this->end_controls_section(); // End Form Settings


		//======================== Featured Images ==========================//
		$this->start_controls_section(
			'featured_images', [
				'label' => __( 'Featured Images', 'listy-core' ),
			]
		);

		$this->add_control(
			'fimage', [
				'label' => esc_html__( 'Featured Image', 'listy-core' ),
				'type'  => Controls_Manager::MEDIA,
			]
		);

		$this->add_control(
			'shape1', [
				'label' => esc_html__( 'Shape', 'listy-core' ),
				'type'  => Controls_Manager::MEDIA,
			]
		);

		$this->add_control(
			'shape2', [
				'label' => esc_html__( 'Shape 2', 'listy-core' ),
				'type'  => Controls_Manager::MEDIA,
			]
		);

		$this->end_controls_section(); // End Featured Images

	}


	/**
	 * Name: elementor_style_control()
	 * Desc: Register style content
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	public function elementor_style_control() {

	}


	/**
	 * Name: elementor_render()
	 * Desc: Render widget output on the frontend.
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		extract( $settings ); //Array to variable conversation


		$user_login = ( ! empty( $_POST['user_login'] ) ) ? sanitize_text_field( $_POST['user_login'] ) : '';
		$email      = ( ! empty( $_POST['user_email'] ) ) ? sanitize_text_field( $_POST['user_email'] ) : '';
		$password   = ( ! empty( $_POST['user_pwd'] ) ) ? $_POST['user_pwd'] : '';

		if ( is_user_logged_in() ) {
			$current_user = wp_get_current_user();
			?>
            <section class="sign-up-wrapper">
                <div class="container">
                    <h2 class="text-center signup_title"><?php esc_html_e( 'Welcome ', 'listy-core' ) ?><?php echo $current_user->display_name; ?> </h2>
                    <div class="signup-login-form">
                        <p> <?php esc_html_e( 'You are logged in', 'listy-core' ) ?> </p>
                        <p> <?php esc_html_e( 'You can logout from', 'listy-core' ) ?>
                            <a href="<?php echo esc_url( wp_logout_url( home_url( '/' ) ) ) ?>"> <?php esc_html_e( 'here', 'listy-core' ) ?> </a>
                        </p>
                        <p> <?php esc_html_e( 'Or navigate to the website', 'listy-core' ) ?>
                            <a href="<?php echo esc_url( home_url( '/' ) ) ?>"> <?php esc_html_e( 'Homepage', 'listy-core' ) ?> </a>
                        </p>
                    </div>
                </div>
            </section>
			<?php
		} else {
			?>

            <section class="signup_area signup_area_height">
                <div class="row me-0 ms-0">
                    <div class="sign_left signup_left">
                        <h2>We are design changers do what matters.</h2>
						<?php
						if ( ! empty( $settings['shape1']['id'] ) ) {
							echo wp_get_attachment_image( $settings['shape1']['id'], 'full', '', [ 'class' => 'position-absolute top' ] );
						}
						if ( ! empty( $settings['shape2']['id'] ) ) {
							echo wp_get_attachment_image( $settings['shape2']['id'], 'full', '', [ 'class' => 'position-absolute bottom' ] );
						}
						if ( ! empty( $settings['fimage']['id'] ) ) {
							echo wp_get_attachment_image( $settings['fimage']['id'], 'full', '', [ 'class' => 'position-absolute middle wow fadeInRight' ] );
						}
						?>
                        <div class="round wow zoomIn" data-wow-delay="0.2s"></div>
                    </div>
                    <div class="sign_right signup_right">
                        <div class="sign_inner signup_inner">
                            <div class="text-center">
                                <h3><?php esc_html_e( 'Create your Account', 'listy-core' ); ?></h3>
                                <p><?php esc_html_e( 'Already have an account?', 'listy-core' ); ?>
                                    <a <?php Listy_Core_Helper()->the_button( $settings['signin_btn_url'] ) ?>>
										<?php echo esc_html( $signin_btn_label ) ?>
                                    </a>
                                </p>
                            </div>
                            <div class="divider">
                                <span class="or-text">or</span>
                            </div>

                            <form action="<?php echo esc_url( home_url( '/' ) ) ?>wp-login.php?action=register"
                                  name="registerform" id="registerform" class="row login_form" method="post">
                                <div class="col-lg-12 form-group">
                                    <div class="small_text"><?php esc_html_e( 'Username', 'listy-core' ) ?></div>
                                    <input type="text" class="form-control" name="username" id="username"
                                           value="<?php echo esc_attr( $user_login ) ?>"
                                           placeholder="<?php esc_attr_e( 'arifrahman*', 'listy-core' ); ?>">
                                </div>
                                <div class="col-lg-12 form-group">
                                    <div class="small_text"><?php esc_html_e( 'Your Email', 'listy-core' ); ?></div>
                                    <input type="email" class="form-control" name="email" id="email"
                                           value="<?php echo esc_attr( $email ) ?>"
                                           placeholder="<?php esc_attr_e( 'info@listy.com', 'listy-core' ); ?>">
                                </div>
                                <div class="col-lg-12 form-group">
                                    <div class="small_text"><?php esc_html_e( 'Password', 'listy-core' ); ?></div>
                                    <input id="password" name="password" type="password" class="form-control"
                                           value="<?php echo esc_attr( $password ) ?>"
                                           placeholder="******" autocomplete="off">
                                </div>
                                <div class="col-lg-12 form-group">
                                    <div class="check_box">
                                        <input type="checkbox" value="None" id="squared2" name="check">
                                        <label class="l_text" for="squared2">I accept the <span>politic of
                                            confidentiality</span></label>
                                    </div>
                                </div>
                                <div class="col-lg-12 text-center">
                                    <button type="submit"
                                            class="btn action_btn thm_btn"><?php esc_html_e( 'Create an account', 'listy-core' ); ?></button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </section>
			<?php
		}

		// Error Handling
		global $errors;
		$errors = new \WP_Error;
		if ( empty( $_POST['user_login'] ) || ! empty( $_POST['user_login'] ) && trim( $_POST['user_login'] ) == '' ) {
			$errors->add( 'user_login_error', sprintf( '<strong>%s</strong>: %s', __( 'ERROR', 'listy-core' ), __( 'You must include a user_login.', 'listy-core' ) ) );
		}
		if ( empty( $_POST['user_email'] ) || ! empty( $_POST['user_email'] ) && trim( $_POST['user_email'] ) == '' ) {
			$errors->add( 'email_error', sprintf( '<strong>%s</strong>: %s', __( 'ERROR', 'listy-core' ), __( 'You must include an email.', 'listy-core' ) ) );
		}
		if ( empty( $_POST['password'] ) || ! empty( $_POST['password'] ) && trim( $_POST['password'] ) == '' ) {
			$errors->add( 'password_error', sprintf( '<strong>%s</strong>: %s', __( 'ERROR', 'listy-core' ), __( 'You must enter a password.', 'listy-core' ) ) );
		}

	}
}