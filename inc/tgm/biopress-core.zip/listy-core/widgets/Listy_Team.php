<?php

namespace ListyCore\Widgets;

// Exit if accessed directly
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Image_hover
 * @package ListyCore\Widgets
 */
class Listy_Team extends \Elementor\Widget_Base {

	public function get_name() {
		return 'listy_team';
	}

	public function get_title() {
		return __( 'Listy Team (Listy)', 'listy-core' );
	}

	public function get_icon() {
		return 'eicon-person';
	}

	public function get_style_depends() {
		return [ 'slick-theme', 'slick' ];
	}

	public function get_script_depends() {
		return [ 'slick' ];
	}

	public function get_categories() {
		return [ 'listy-elements' ];
	}

	/**
	 * Name: register_controls()
	 * Desc: Register controls for these widgets
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	protected function register_controls() {
		$this->elementor_content_control();
		$this->elementor_style_control();
	}


	/**
	 * Name: elementor_content_control()
	 * Desc: Register content
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	public function elementor_content_control() {

		//============================== Team Member ===============================//
		$this->start_controls_section(
			'team_sec', [
				'label' => __( 'Team', 'plugin-name' ),
			]
		);

		$this->add_control(
			'image', [
				'label'   => __( 'Image', 'listy-core' ),
				'type'    => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		//==== Repeater Icon
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'icon', [
				'label'   => esc_html__( 'Social Icon', 'plugin-name' ),
				'type'    => \Elementor\Controls_Manager::ICONS,
				'default' => [
					'value'   => 'fas fa-facebook-f',
					'library' => 'fa-solid',
				],
			]
		);

		$repeater->add_control(
			'icon_url', [
				'label'   => esc_html__( 'Icon URL', 'plugin-name' ),
				'type'    => \Elementor\Controls_Manager::URL,
				'default' => [
					'url' => '#'
				],
			]
		);

		$this->add_control(
			'social_icons', [
				'label'         => __( 'Add Social Icon', 'listy-core' ),
				'type'          => \Elementor\Controls_Manager::REPEATER,
				'fields'        => $repeater->get_controls(),
				'title_field'   => '{{{ icon.value }}}',
				'prevent_empty' => false,
			]
		); //End Icon

		$this->end_controls_section(); //End Team

	}


	/**
	 * Name: elementor_style_control()
	 * Desc: Register style content
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	public function elementor_style_control() {


	}


	/**
	 * Name: elementor_render()
	 * Desc: Render widget output on the frontend.
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		extract( $settings ); //Array to variable conversation

		?>
        <div class="team-leader-item text-center">
            <div class="item-img mb-0">
                <div class="team-social-link">
                    <ul>
						<?php
						if ( ! empty( $social_icons ) ) {
							foreach ( $social_icons as $icon ) {
								?>
                                <li>
                                    <a <?php Listy_Core_Helper()->the_button( $icon['icon_url'] ) ?>>
										<?php \Elementor\Icons_Manager::render_icon( $icon['icon'] ); ?>
                                    </a>
                                </li>
								<?php
							}
						}
						?>
                    </ul>
                </div>
				<?php echo wp_get_attachment_image( $settings['image']['id'], 'full' ) ?>
            </div>
        </div>
		<?php
	}
}