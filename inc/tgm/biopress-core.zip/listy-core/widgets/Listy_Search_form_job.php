<?php

namespace ListyCore\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Widget_Base;

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}


/**
 * Class Image_hover
 * @package BancaCore\Widgets
 */
class Listy_Search_form_job extends Widget_Base {
	public function get_name() {
		return 'listy_search_form';
	}

	public function get_title() {
		return __( 'Listy Job Search Form (Theme)', 'listy-core' );
	}

	public function get_icon() {
		return 'eicon-search-results';
	}

	public function get_categories() {
		return [ 'listy-elements' ];
	}

	public function get_keywords() {
		return [ 'Search Form Job', 'Search' ];
	}

	/**
	 * Name: register_controls()
	 * Desc: Register controls for these widgets
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @banca
	 * Author: spider-themes
	 */
	protected function register_controls() {
		$this->elementor_content_control();
		$this->elementor_style_control();
	}

	/**
	 * Name: elementor_content_control()
	 * Desc: Register content
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @banca
	 * Author: spider-themes
	 */
	public function elementor_content_control() {


		// ---------------------------------------- Search Form ------------------------------
		$this->start_controls_section(
			'search_form', [
				'label' => __( 'Search Form', 'listy-core' ),
			]
		);

		$this->add_control(
			'search_job_placeholder', [
				'label'       => esc_html__( 'Search Jobs Placeholder', 'listy-core' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => 'Job title, keywords or company',
			]
		);

		$this->add_control(
			'search_area_placeholder', [
				'label'       => esc_html__( 'Search Area Placeholder', 'listy-core' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => 'Town or region',
			]
		);

		$this->add_control(
			'search_btn', [
				'label'       => esc_html__( 'Button Label', 'listy-core' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => 'Search',
			]
		);

		$this->end_controls_section(); // End Search Form

	}


	/**
	 * Name: elementor_style_control()
	 * Desc: Register style
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @banca
	 * Author: spider-themes
	 */
	public function elementor_style_control() {


		//============================== Style Search Form ================================//
		$this->start_controls_section(
			'style_search_form', [
				'label' => __( 'Search Form', 'listy-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'placeholder_text_color', [
				'label'     => __( 'Placeholder Text Color', 'listy-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .faq_search .form-control'   => 'color: {{VALUE}};',
					'{{WRAPPER}} .tavel_search .form-control' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'form_bg_style',
				'label'    => __( 'Background', 'listy-core' ),
				'types'    => [ 'classic', 'gradient' ],
				'exclude'  => [ 'image' ],
				'selector' => '
                    {{WRAPPER}} .faq_search .form-control,
                    {{WRAPPER}} .tavel_search .form-control
                ',
			]
		);

		$this->end_controls_section(); //End Search Form

	}


	/**
	 * Name: elementor_render()
	 * Desc: Render widget
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @banca
	 * Author: spider-themes
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		extract( $settings ); //Array to Variable Conversation

		$search_job_placeholder  = ! empty( $settings['search_job_placeholder'] ) ? $settings['search_job_placeholder'] : '';
		$search_area_placeholder = ! empty( $settings['search_area_placeholder'] ) ? $settings['search_area_placeholder'] : '';
		$search_btn              = ! empty( $settings['search_btn'] ) ? $settings['search_btn'] : '';

		?>
        <div class="search-job">
            <form action="<?php echo esc_url( home_url( '/' ) ) ?>" role="search" method="get" id="searchform">
                <div class="row searchJobDynamicFocus search-box align-items-center py-3 gy-md-0 gy-3">
                    <div class="col-lg-6 col-md-5 border-end">
                        <div class="input-field">
                            <span><i class="las la-briefcase "></i></span>
                            <input type="search" class="form-control" name="s" value="<?php the_search_query(); ?>"
                                   placeholder="<?php echo esc_attr( $search_job_placeholder ) ?>">
                            <input type="hidden" name="post_type" value="job"/>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="input-field">
                            <span><i class="las la-map-marker-alt"></i></span>
                            <input class="form-control" type="text"
                                   placeholder="<?php echo esc_attr( $search_area_placeholder ) ?>">
                            <input type="hidden" name="taxonomy" value="job_location"/>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-3 text-md-end text-center pe-2">
                        <button type="submit" class="custom-btn">
							<?php echo esc_html( $search_btn ) ?>
                        </button>
                    </div>
                </div>
            </form>
        </div>
		<?php
	}
}