<?php

namespace ListyCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Image_hover
 * @package ListyCore\Widgets
 */
class Listy_Pricing_Switcher extends Widget_Base {
	public function get_name() {
		return 'listy_pricing_table_switcher';
	}

	public function get_title() {
		return __( 'Pricing Table Switcher', 'listy-core' );
	}

	public function get_icon() {
		return 'eicon-price-table';
	}

	public function get_categories() {
		return [ 'listy-elements' ];
	}

	/**
	 * Name: register_controls()
	 * Desc: Register controls for these widgets
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	protected function register_controls() {
		$this->elementor_content_control();
		$this->elementor_style_control();
	}


	/**
	 * Name: elementor_content_control()
	 * Desc: Register content
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	public function elementor_content_control() {

		//========================== Table Table ============================//
		$this->start_controls_section(
			'pricing_table_sec', [
				'label' => esc_html__( 'Pricing Table', 'listy-core' ),
			]
		);

		$this->start_controls_tabs(
			'pricing_table_tabs'
		);

		//==== Monthly Tabs
		$this->start_controls_tab(
			'monthly_tab', [
				'label' => esc_html__( 'Tab 01', 'plugin-name' ),
			]
		);

		$this->add_control(
			'tab1_title', [
				'label'     => esc_html__( 'Tab Title', 'listy-core' ),
				'type'      => \Elementor\Controls_Manager::TEXT,
				'default'   => 'Monthly',
				'separator' => 'after'
			]
		);

		$this->add_control(
			'tab1_old_price', [
				'label'   => esc_html__( 'Old Price', 'listy-core' ),
				'type'    => \Elementor\Controls_Manager::TEXT,
				'default' => '99.99',
			]
		);

		$this->add_control(
			'tab1_current_price', [
				'label'   => esc_html__( 'Current Price', 'listy-core' ),
				'type'    => \Elementor\Controls_Manager::TEXT,
				'default' => '79.49',
			]
		);

		$this->add_control(
			'tab1_discount_price', [
				'label'   => esc_html__( 'Discount Price', 'listy-core' ),
				'type'    => \Elementor\Controls_Manager::TEXT,
				'default' => '$45.25% OFF',
			]
		);

		$this->add_control(
			'tab1_duration', [
				'label'   => esc_html__( 'Duration', 'listy-core' ),
				'type'    => \Elementor\Controls_Manager::TEXT,
				'default' => ' /month',
			]
		);

		$this->add_control(
			'tab1_bottom_content', [
				'label'       => esc_html__( 'Contents', 'listy-core' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => 'for the first month',
				'label_block' => true,
			]
		);

		$this->end_controls_tab();//End Monthly Tab

		//==== Yearly Tabs
		$this->start_controls_tab(
			'yearly_tab', [
				'label' => esc_html__( 'Tab 02', 'plugin-name' ),
			]
		);

		$this->add_control(
			'tab2_title', [
				'label'   => esc_html__( 'Tab Title', 'listy-core' ),
				'type'    => \Elementor\Controls_Manager::TEXT,
				'default' => 'Annual',
			]
		);

		$this->add_control(
			'tab2_old_price', [
				'label'   => esc_html__( 'Old Price', 'listy-core' ),
				'type'    => \Elementor\Controls_Manager::TEXT,
				'default' => '99.99',
			]
		);

		$this->add_control(
			'tab2_current_price', [
				'label'   => esc_html__( 'Current Price', 'listy-core' ),
				'type'    => \Elementor\Controls_Manager::TEXT,
				'default' => '79.49',
			]
		);

		$this->add_control(
			'tab2_discount_price', [
				'label'   => esc_html__( 'Discount Price', 'listy-core' ),
				'type'    => \Elementor\Controls_Manager::TEXT,
				'default' => '$45.25% OFF',
			]
		);

		$this->add_control(
			'tab2_duration', [
				'label'   => esc_html__( 'Duration', 'listy-core' ),
				'type'    => \Elementor\Controls_Manager::TEXT,
				'default' => ' /year',
			]
		);

		$this->add_control(
			'tab2_bottom_content', [
				'label'       => esc_html__( 'Contents', 'listy-core' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => 'for the first year',
				'label_block' => true,
			]
		);

		$this->end_controls_tab();

		$this->end_controls_tabs(); //End Tabs

		$this->end_controls_section(); //End Table Style 06

	}


	/**
	 * Name: elementor_style_control()
	 * Desc: Register style content
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	public function elementor_style_control() {


		//=============================== Table Contents ===================================//
		$this->start_controls_section(
			'pricing_style', [
				'label' => esc_html__( 'Style', 'listy-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->end_controls_section(); //End Section Contents

	}


	/**
	 * Name: elementor_render()
	 * Desc: Render widget output on the frontend.
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		extract( $settings ); //Array to variable conversation

		?>
        <div class="price-contant">
            <ul class="nav nav-tabs pricing-switcher-2 mb-20" id="myTab" role="tablist">

                <li class="switcher-bg"></li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link month active" id="monthly-tab" data-bs-toggle="tab"
                            data-bs-target="#monthly" type="button" role="tab" aria-controls="monthly"
                            aria-selected="true">
						<?php echo esc_html( $settings['tab1_title'] ) ?>
                    </button>
                </li>
                <li class="nav-item" role="presentation">
                    <button class="nav-link annual" id="annual-tab" data-bs-toggle="tab"
                            data-bs-target="#annual" type="button" role="tab" aria-controls="annual"
                            aria-selected="false">
						<?php echo esc_html( $settings['tab2_title'] ) ?>
                    </button>
                </li>

            </ul>

            <div class="tab-content" id="myTabContent">

                <!-------------------------- Monthly Tabs ------------------------------>
                <div class="tab-pane fade show active" id="monthly" role="tabpanel" aria-labelledby="monthly-tab">
					<?php
					if ( ! empty( $settings['tab1_old_price'] ) ) { ?>
                        <p class="old-price mb-10"><?php echo esc_html( $settings['tab1_old_price'] ) ?></p>
						<?php
					}
					if ( ! empty( $settings['tab1_current_price'] ) ) { ?>
                        <div class="d-flex">
                            <p class="current-price"><?php echo esc_html( $settings['tab1_current_price'] ) ?></p>
                            <button class="saving-price ml-15"><?php echo esc_html( $settings['tab1_discount_price'] ) ?></button>
                        </div>
						<?php
					}
					if ( ! empty( $settings['tab1_bottom_content'] ) ) { ?>
                        <p class="price-format"><?php echo esc_html( $settings['tab1_bottom_content'] ) ?></p>
						<?php
					}
					?>
                </div>

                <!-------------------------- Yearly Tabs ------------------------------>
                <div class="tab-pane fade" id="annual" role="tabpanel" aria-labelledby="annual-tab">
					<?php
					if ( ! empty( $settings['tab2_old_price'] ) ) { ?>
                        <p class="old-price mb-10"><?php echo esc_html( $settings['tab2_old_price'] ) ?></p>
						<?php
					}
					if ( ! empty( $settings['tab2_current_price'] ) ) { ?>
                        <div>
                            <p class="current-price"><?php echo esc_html( $settings['tab2_current_price'] ) ?></p>
                            <button class="saving-price ml-15"><?php echo esc_html( $settings['tab2_discount_price'] ) ?></button>
                        </div>
						<?php
					}
					if ( ! empty( $settings['tab2_bottom_content'] ) ) { ?>
                        <p class="price-format"><?php echo esc_html( $settings['tab2_bottom_content'] ) ?></p>
						<?php
					}
					?>
                </div>
            </div>
        </div>
		<?php

	}

}