<?php

namespace ListyCore\Widgets;

// Exit if accessed directly
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Image_hover
 * @package ListyCore\Widgets
 */
class Listy_Process extends \Elementor\Widget_Base {

	public function get_name() {
		return 'listy_process';
	}

	public function get_title() {
		return __( 'Listy Process (Listy)', 'listy-core' );
	}

	public function get_icon() {
		return 'eicon-video-camera';
	}

	public function get_style_depends() {
		return [ 'slick-theme', 'slick' ];
	}

	public function get_script_depends() {
		return [ 'slick' ];
	}

	public function get_categories() {
		return [ 'listy-elements' ];
	}

	/**
	 * Name: register_controls()
	 * Desc: Register controls for these widgets
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	protected function register_controls() {
		$this->elementor_content_control();
		$this->elementor_style_control();
	}

	/**
	 * Name: elementor_content_control()
	 * Desc: Register content
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	public function elementor_content_control() {

		//======================== Content ========================//
		$this->start_controls_section(
			'content_sec', [
				'label' => esc_html__( 'Content', 'listy-core' ),
			]
		);
		$this->add_control(
			'number', [
				'label'   => esc_html__( 'Number', 'listy-core' ),
				'type'    => \Elementor\Controls_Manager::NUMBER,
				'default' => esc_html__( '1', 'listy-core' ),
			]
		);
		$this->add_control(
			'title', [
				'label'       => esc_html__( 'Title', 'listy-core' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => esc_html__( 'Claim', 'listy-core' ),
			]
		);
		$this->add_control(
			'content', [
				'label'   => esc_html__( 'Content', 'listy-core' ),
				'type'    => \Elementor\Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'Best way to start managing your business listing is by claiming it so you can update.', 'listy-core' ),
			]
		);

		$this->end_controls_section(); // End content section
	}


	/**
	 * Name: elementor_style_control()
	 * Desc: Register style content
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	public function elementor_style_control() {

		//======================== Video Icon ========================//
		$this->start_controls_section(
			'style_content', [
				'label' => esc_html__( 'Contents', 'listy-core' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
		$this->add_control(
			'number_style', [
				'label'     => esc_html__( 'Number', 'textdomain' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control(
			'number_color', [
				'label'     => esc_html__( 'Color', 'listy-core' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .__number' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(), [
				'name'     => 'number_typo',
				'selector' => '{{WRAPPER}} .__number',
			]
		);
		$this->add_control(
			'title_style', [
				'label'     => esc_html__( 'Title', 'textdomain' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control(
			'title_color', [
				'label'     => esc_html__( 'Color', 'listy-core' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .__title' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(), [
				'name'     => 'title_typo',
				'selector' => '{{WRAPPER}} .__title',
			]
		);
		$this->add_control(
			'content_style', [
				'label'     => esc_html__( 'Content', 'textdomain' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
		$this->add_control(
			'content_color', [
				'label'     => esc_html__( 'Color', 'listy-core' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .__content' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(), [
				'name'     => 'content_typo',
				'selector' => '{{WRAPPER}} .__content',
			]
		);

		$this->end_controls_section(); //End Video Icon
	}

	/**
	 * Name: elementor_render()
	 * Desc: Render widget output on the frontend.
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		extract( $settings ); //Array to variable conversation

		?>
        <div class="business-process-item">
			<?php
			if ( ! empty( $settings['number'] ) ) { ?>
                <p class="process-number __number"><?php echo esc_html( $settings['number'] ); ?></p>
				<?php
			}
			if ( ! empty( $settings['title'] ) ) { ?>
                <h4 class="process-title __title"><?php echo esc_html( $settings['title'] ); ?></h4>
				<?php
			}
			if ( ! empty( $settings['content'] ) ) { ?>
                <p class="__content"><?php echo esc_html( $settings['content'] ); ?></p>
				<?php
			}
			?>
        </div>
		<?php

	}
}