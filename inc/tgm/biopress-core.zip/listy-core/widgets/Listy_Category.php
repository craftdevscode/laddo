<?php

namespace ListyCore\Widgets;

// Exit if accessed directly
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Image_hover
 * @package ListyCore\Widgets
 */
class Listy_Category extends \Elementor\Widget_Base {

	public function get_name() {
		return 'listy_category';
	}

	public function get_title() {
		return __( 'Listing Category (Listy)', 'listy-core' );
	}

	public function get_icon() {
		return 'eicon-posts-group';
	}

	public function get_categories() {
		return [ 'listy-elements' ];
	}

	/**
	 * Name: register_controls()
	 * Desc: Register controls for these widgets
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	protected function register_controls() {
		$this->elementor_content_control();
		$this->elementor_style_control();
	}


	/**
	 * Name: elementor_content_control()
	 * Desc: Register content
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	public function elementor_content_control() {

		//===================== Select Preset ===========================//
		$this->start_controls_section(
			'sec_layout', [
				'label' => esc_html__( 'Preset Skins', 'listy-core' ),
			]
		);

		$this->add_control(
			'layout', [
				'label'   => __( 'Layout', 'listy-core' ),
				'type'    => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'1' => [
						'title' => __( '01: Category with Subcategory', 'listy-core' ),
						'icon'  => 'category1',
					],
					'2' => [
						'title' => __( '02: Category Grid', 'listy-core' ),
						'icon'  => 'category2',
					],
					'3' => [
						'title' => __( '03: Category Masonry', 'listy-core' ),
						'icon'  => 'category2',
					],
				],
				'default' => '1'
			]
		);

		$this->end_controls_section();//End Select Style


		//===================== Location Filter =========================//
		$this->start_controls_section(
			'sec_filter', [
				'label' => __( 'Filter', 'listy-core' ),
			]
		);

		$this->add_control(
			'cat', [
				'label'       => esc_html__( 'Category', 'listy-core' ),
				'description' => esc_html__( 'Display Listing by Location', 'listy-core' ),
				'type'        => \Elementor\Controls_Manager::SELECT2,
				'options'     => Listy_Core_Helper()->get_the_categories( 'listing_cat' ),
				'multiple'    => true,
				'label_block' => true,
			]
		);

		$this->add_control(
			'show_count', [
				'label'   => esc_html__( 'Show Posts Count', 'banca-core' ),
				'type'    => \Elementor\Controls_Manager::NUMBER,
				'default' => 4
			]
		);

		$this->add_control(
			'column', [
				'label'   => esc_html__( 'Column', 'listy-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'6' => esc_html__( 'Two', 'listy-core' ),
					'4' => esc_html__( 'Three', 'listy-core' ),
					'3' => esc_html__( 'Four', 'listy-core' ),
					'2' => esc_html__( 'Six', 'listy-core' ),
				],
				'default' => 2,
			]
		);

		$this->end_controls_section(); //End Location Filter

	}


	/**
	 * Name: elementor_style_control()
	 * Desc: Register style content
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	public function elementor_style_control() {

		//===================== Section Title ===========================//
		$this->start_controls_section(
			'sec_title', [
				'label' => esc_html__( 'Section Title', 'listy-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color', [
				'label'     => esc_html__( 'Title Color', 'listy-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .__title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(), [
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .__title',
			]
		);

		$this->end_controls_section(); // End Section Title


		//===================== Section Background ===========================//
		$this->start_controls_section(
			'style_background', [
				'label'     => esc_html__( 'Background', 'listy-core' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [
					'layout' => '1'
				]
			]
		);

		$this->add_responsive_control(
			'sec_margin', [
				'label'      => __( 'Margin', 'listy-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .__listy_sec' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'sec_padding', [
				'label'      => __( 'Padding', 'listy-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .__listy_sec' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(), [
				'name'     => 'sec_bg_color',
				'label'    => __( 'Background', 'listy-core' ),
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .__listy_sec',
			]
		);

		$this->end_controls_section(); //End Section Background


	}


	/**
	 * Name: elementor_render()
	 * Desc: Render widget output on the frontend.
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		extract( $settings ); //Array to variable conversation

		$id_int = substr( $this->get_id_int(), 0, 1 );

		$categories = get_terms( array(
			'taxonomy'   => 'listing_cat',
			'hide_empty' => false,
			'number'     => ! empty( $show_count ) ? $show_count : 4,
			'parent'     => 0,
			'include'    => ! empty( $settings['cat'] ) ? $settings['cat'] : array(),
		) );


		//====== Template Parts
		include "template/categories/category-{$settings['layout']}.php";

	}
}