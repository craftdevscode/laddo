<?php

namespace ListyCore\Widgets;

// Exit if accessed directly
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Image_hover
 * @package ListyCore\Widgets
 */
class Listy_Search_Form extends \Elementor\Widget_Base {

	public function get_name() {
		return 'listy_search_form';
	}

	public function get_title() {
		return __( 'Search Form (Listy)', 'listy-core' );
	}

	public function get_icon() {
		return 'eicon-google-maps';
	}

	public function get_categories() {
		return [ 'listy-elements' ];
	}


	/**
	 * Name: register_controls()
	 * Desc: Register controls for these widgets
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	protected function register_controls() {
		$this->elementor_content_control();
		$this->elementor_style_control();
	}


	/**
	 * Name: elementor_content_control()
	 * Desc: Register content
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	public function elementor_content_control() {

		//===================== Select Preset ===========================//
		$this->start_controls_section(
			'sec_layout', [
				'label' => esc_html__( 'Preset Skins', 'listy-core' ),
			]
		);

		$this->add_control(
			'layout', [
				'label'   => esc_html__( 'Layout', 'listy-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'1' => esc_html__( '01: Listing Locations', 'listy-core' ),
					'2' => esc_html__( '02: Listing', 'listy-core' ),
				],
				'default' => '1',
			]
		);

		$this->end_controls_section();//End Select Style


		//===================== Filter =========================//
		$this->start_controls_section(
			'listing_cats_sec', [
				'label' => __( 'Search Filter', 'listy-core' ),
			]
		);

		$this->end_controls_section(); // End Filter

		$this->start_controls_section(
			'content_section',
			[
				'label' => esc_html__( 'Content', 'textdomain' ),
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'search_title',
			[
				'label'   => esc_html__( 'Title', 'textdomain' ),
				'type'    => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Explore Your City.', 'textdomain' ),
			]
		);
		$this->add_control(
			'search_content',
			[
				'label'   => esc_html__( 'Content', 'textdomain' ),
				'type'    => \Elementor\Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'Listy helps you find out whats happening in your city', 'textdomain' ),
			]
		);
		$this->add_control(
			'search_button',
			[
				'label'   => esc_html__( 'Button', 'textdomain' ),
				'type'    => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Search', 'textdomain' ),
			]
		);

		$this->end_controls_section();


	}


	/**
	 * Name: elementor_style_control()
	 * Desc: Register style content
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	public function elementor_style_control() {


		//===================== Section Title ===========================//
		$this->start_controls_section(
			'sec_title', [
				'label' => esc_html__( 'Section Title', 'listy-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color', [
				'label'     => esc_html__( 'Title Color', 'listy-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .__title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(), [
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .__title',
			]
		);

		$this->end_controls_section(); // End Section Title


	}


	/**
	 * Name: elementor_render()
	 * Desc: Render widget output on the frontend.
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		extract( $settings ); //Array to variable conversation


		// $locations = get_terms( array(
		// 	'taxonomy' => 'at_biz_dir-location',
		// 	'hide_empty' => true,
		// 	'number' => $show_count != '' ? $show_count : 4,
		// ));

		//====== Template Parts
		include "template/search-form/search-form-{$settings['layout']}.php";

	}

}