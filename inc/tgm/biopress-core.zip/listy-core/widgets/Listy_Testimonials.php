<?php
namespace ListyCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Image_hover
 * @package ListyCore\Widgets
 */
class Listy_Testimonials extends Widget_Base {
    public function get_name() {
        return 'listy_testimonials';
    }

    public function get_title() {
        return __( 'Testimonials (Listy)', 'listy-core' );
    }

    public function get_icon() {
        return 'eicon-testimonial';
    }

    public function get_style_depends() {
        return [ 'slick-theme', 'slick' ];
    }

    public function get_script_depends() {
        return [ 'slick' ];
    }

    public function get_categories() {
        return [ 'listy-elements' ];
    }

    /**
     * Name: register_controls()
     * Desc: Register controls for these widgets
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @listy
     * Author: spider-themes
     */
    protected function register_controls() {
        $this->elementor_content_control();
        $this->elementor_style_control();
    }


    /**
     * Name: elementor_content_control()
     * Desc: Register content
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @listy
     * Author: spider-themes
     */
    public function elementor_content_control() {


        //============================== Testimonials 01 ===============================//
        $this->start_controls_section(
            'testimonials_sec', [
                'label' => __('Testimonials', 'listy-core'),
            ]
        );

        //================ Testimonials 01
        $testimonials1 = new \Elementor\Repeater();
	    $testimonials1->add_control(
		    'author_img', [
			    'label' => __('Author Image', 'listy-core'),
			    'type' => \Elementor\Controls_Manager::MEDIA,
			    'default' => [
				    'url' => \Elementor\Utils::get_placeholder_image_src(),
			    ],
		    ]
	    );

        $testimonials1->add_control(
		    'author_shape', [
			    'label' => __('Shape Image', 'listy-core'),
			    'type' => \Elementor\Controls_Manager::MEDIA,
			    'default' => [
				    'url' => \Elementor\Utils::get_placeholder_image_src(),
			    ],
		    ]
	    );

        $testimonials1->add_control(
            'review_content', [
                'label' => __('Content', 'listy-core'),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
            ]
        );

        $testimonials1->add_control(
            'name', [
                'label' => __('Author Name', 'listy-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Arif Rahamn', 'listy-core'),
            ]
        );

        $testimonials1->add_control(
            'designation', [
                'label' => __('Designation', 'listy-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('Web Developer', 'listy-core'),
            ]
        );

        $this->add_control(
            'testimonials', [
                'label' => __('Add Testimonial', 'listy-core'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $testimonials1->get_controls(),
                'title_field' => '{{{ name }}}',
                'prevent_empty' => false,
            ]
        );

        $this->end_controls_section(); // End Testimonials Style

    }


    /**
     * Name: elementor_style_control()
     * Desc: Register style content
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @listy
     * Author: spider-themes
     */
    public function elementor_style_control () {


        //============================ Style Author Name =============================//
        $this->start_controls_section(
            'author_name_style', [
                'label' => __( 'Author Section', 'listy-core' ),
                'tab' => Controls_Manager::TAB_STYLE,
            ]
        );

        //==================== Author Name
        $this->add_control(
            'author_name_divider', [
                'label' => __( 'Author Name', 'listy-core' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'author_name_color', [
                'label' => __( 'Text Color', 'listy-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .__name' => 'color: {{VALUE}};',
                ]
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(),
            [
                'name' => 'author_name_typo',
                'selector' => '{{WRAPPER}} .__name',
            ]
        );


        //============== Designation
        $this->add_control(
            'designation_divider', [
                'label' => __( 'Designation', 'listy-core' ),
                'type' => Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'designation_color', [
                'label' => __( 'Text Color', 'listy-core' ),
                'type' => Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .__designation' => 'color: {{VALUE}};',
                ]
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Typography::get_type(), [
                'name' => 'designation_typo',
                'selector' => '{{WRAPPER}} .__designation',
            ]
        );


	    //============== Review Content
	    $this->add_control(
		    'review_content_divider', [
			    'label' => __( 'Review Content', 'listy-core' ),
			    'type' => Controls_Manager::HEADING,
			    'separator' => 'before',
		    ]
	    );

	    $this->add_control(
		    'content_color', [
			    'label' => __( 'Text Color', 'listy-core' ),
			    'type' => Controls_Manager::COLOR,
			    'selectors' => [
				    '{{WRAPPER}} .__content' => 'color: {{VALUE}};',
			    ]
		    ]
	    );

	    $this->add_group_control(
		    \Elementor\Group_Control_Typography::get_type(), [
			    'name' => 'content_typo',
			    'selector' => '{{WRAPPER}} .__content',
		    ]
	    );

        $this->end_controls_section(); // End author section


        //=========================== Section Background ==============================//
        $this->start_controls_section(
            'style_background', [
                'label' => __( 'Background', 'listy-core' ),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_responsive_control(
            'sec_margin', [
                'label' => __( 'Margin', 'listy-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .__listy_sec' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_responsive_control(
            'sec_padding', [
                'label' => __( 'Padding', 'listy-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .__listy_sec' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

        $this->add_group_control(
            \Elementor\Group_Control_Background::get_type(), [
                'name' => 'sec_bg_color',
                'label' => __( 'Background', 'listy-core' ),
                'types' => [ 'classic', 'gradient' ],
                'selector' => '{{WRAPPER}} .__listy_sec',
            ]
        );

        $this->end_controls_section(); //End Section Background

    }


    /**
     * Name: elementor_render()
     * Desc: Render widget output on the frontend.
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @listy
     * Author: spider-themes
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        extract($settings); // Array to Variable Conversation

        $title = !empty( $settings['title'] ) ? $settings['title'] : '';
        $title_tag = !empty( $settings['title_tag'] ) ? $settings['title_tag'] : '';

        // Include Style
        include "template/testimonials/testimonial-1.php";

    }

}