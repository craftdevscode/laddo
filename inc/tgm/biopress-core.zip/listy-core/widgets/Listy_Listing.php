<?php

namespace ListyCore\Widgets;

// Exit if accessed directly
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Image_hover
 * @package ListyCore\Widgets
 */
class Listy_Listing extends \Elementor\Widget_Base {

	public function get_name() {
		return 'listy_listing';
	}

	public function get_title() {
		return __( 'Listings (Listy)', 'listy-core' );
	}

	public function get_icon() {
		return 'eicon-gallery-grid';
	}

	public function get_style_depends() {
		return [ 'slick-theme', 'slick' ];
	}

	public function get_script_depends() {
		return [ 'slick' ];
	}

	public function get_categories() {
		return [ 'listy-elements' ];
	}


	/**
	 * Name: register_controls()
	 * Desc: Register controls for these widgets
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	protected function register_controls() {
		$this->elementor_content_control();
		$this->elementor_style_control();
	}


	/**
	 * Name: elementor_content_control()
	 * Desc: Register content
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	public function elementor_content_control() {

		//===================== Select Preset ===========================//
		$this->start_controls_section(
			'sec_layout', [
				'label' => esc_html__( 'Preset Skins', 'listy-core' ),
			]
		);

		$this->add_control(
			'layout', [
				'label'   => esc_html__( 'Layout', 'listy-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'1' => esc_html__( '01: Listing Grid', 'listy-core' ),
				],
				'default' => '1',
			]
		);

		$this->end_controls_section();//End Select Style


		//===================== Location Filter =========================//
		$this->start_controls_section(
			'sec_filter', [
				'label' => __( 'Filter', 'listy-core' ),
			]
		);

		$this->add_control(
			'show_count', [
				'label'   => esc_html__( 'Show Posts Count', 'banca-core' ),
				'type'    => \Elementor\Controls_Manager::NUMBER,
				'default' => 4
			]
		);

		$this->add_control(
			'column', [
				'label'   => esc_html__( 'Column', 'listy-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'6' => esc_html__( 'Two', 'listy-core' ),
					'4' => esc_html__( 'Three', 'listy-core' ),
					'3' => esc_html__( 'Four', 'listy-core' ),
				],
				'default' => 3,
			]
		);

		$this->end_controls_section(); // End Location Filter


	}


	/**
	 * Name: elementor_style_control()
	 * Desc: Register style content
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	public function elementor_style_control() {


		//===================== Section Title ===========================//
		$this->start_controls_section(
			'sec_title', [
				'label' => esc_html__( 'Section Title', 'listy-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color', [
				'label'     => esc_html__( 'Title Color', 'listy-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .__title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(), [
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .__title',
			]
		);

		$this->end_controls_section(); // End Section Title


	}


	/**
	 * Name: elementor_render()
	 * Desc: Render widget output on the frontend.
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		extract( $settings ); //Array to variable conversation


		$paged  = get_query_var( 'paged' ) ? get_query_var( 'paged' ) : 1;
		$sticky = get_option( 'sticky_posts' );

		$args = [
			'post_type'   => 'listing',
			'post_status' => 'publish',
			'paged'       => $paged,
		];

		if ( ! empty( $show_count ) ) {
			$args['posts_per_page'] = $show_count;
		}

		if ( ! empty( $order ) ) {
			$args['order'] = $order;
		}

		if ( ! empty( $orderby ) ) {
			$args['orderby'] = $orderby;
		}

		if ( ! empty( $exclude ) ) {
			$args['post__not_in'] = $exclude;
		}

		if ( ! empty( $cats ) ) {
			$args['tax_query'] = [
				[
					'taxonomy' => 'listing_cat',
					'field'    => 'id',
					'terms'    => $cats

				]
			];
		}


		$listing_post = new \WP_Query( $args );

		//====== Template Parts
		include "template/listings/listing-{$settings['layout']}.php";

	}
}