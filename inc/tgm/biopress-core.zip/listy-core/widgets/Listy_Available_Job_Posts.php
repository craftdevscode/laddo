<?php

namespace ListyCore\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Widget_Base;


// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Image_hover
 * @package ListyCore\Widgets
 */
class Listy_Available_Job_Posts extends Widget_Base {

	public function get_name() {
		return 'bjl_available_job_posts';
	}

	public function get_title() {
		return __( 'Listy Available Job Posts (Theme)', 'listy-core' );
	}

	public function get_icon() {
		return 'eicon-counter-circle';
	}

	public function get_categories() {
		return [ 'listy-elements' ];
	}

	/**
	 * Name: register_controls()
	 * Desc: Register controls for these widgets
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	protected function register_controls() {
		$this->elementor_content_control();
		$this->elementor_style_control();
	}

	/**
	 * Name: elementor_content_control()
	 * Desc: Register content
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	public function elementor_content_control() {
		//============================ Job Post Count Titles ===========================//
		$this->start_controls_section(
			'post_count_title_sec', [
				'label' => __( 'Step Title', 'listy-core' ),
			]
		);

		$this->add_control(
			'post_count_title', [
				'label'       => __( 'Post Count Title', 'listy-core' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => 'Jobs Available'
			]
		);

		$this->end_controls_section(); //End Step Titles


	}


	/**
	 * Name: elementor_style_control()
	 * Desc: Register style
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	public function elementor_style_control() {

		//============================ Style Step Item List =================================//
		$this->start_controls_section(
			'style_step_item_list', [
				'label' => __( 'Step Contents', 'listy-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_control(
			'title_color', [
				'label'     => __( 'Text Color', 'listy-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .title' => 'color: {{VALUE}}',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(), [
				'name'     => 'title_typo',
				'label'    => __( 'Typography', 'plugin-domain' ),
				'selector' => '{{WRAPPER}} .title',
			]
		);

		$this->end_controls_section(); //End Style Step Item List

	}


	/**
	 * Name: elementor_render()
	 * Desc: Render widget
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();

		?>
        <p class="title">
			<?php echo esc_html( Listy_Core_Helper()->get_the_job_post_count() ); ?>
			<?php echo esc_html( $settings['post_count_title'] ) ?>
        </p>
		<?php
	}
}