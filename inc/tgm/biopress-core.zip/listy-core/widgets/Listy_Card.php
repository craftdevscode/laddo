<?php
namespace ListyCore\Widgets;

// Exit if accessed directly
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Class Image_hover
 * @package ListyCore\Widgets
 */
class Listy_Card extends \Elementor\Widget_Base {

    public function get_name() {
        return 'listy_card';
    }

    public function get_title() {
        return __( 'Listing Card (Listy)', 'listy-core' );
    }

    public function get_icon() {
        return 'eicon-posts-group';
    }

    public function get_categories() {
        return [ 'listy-elements' ];
    }

    /**
     * Name: register_controls()
     * Desc: Register controls for these widgets
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @listy
     * Author: spider-themes
     */
    protected function register_controls() {
        $this->elementor_content_control();
        $this->elementor_style_control();
    }


    /**
     * Name: elementor_content_control()
     * Desc: Register content
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @listy
     * Author: spider-themes
     */
    public function elementor_content_control() {

        //===================== Select Preset ===========================//
        $this->start_controls_section(
            'sec_layout', [
                'label' => esc_html__( 'Preset Skins', 'listy-core' ),
            ]
        );

        $this->add_control(
            'layout', [
                'label'   => esc_html__( 'Layout', 'listy-core' ),
                'type'    => Controls_Manager::SELECT,
                'options' => [
                    '1' => esc_html__( '01: Card', 'listy-core' ),
                ],
                'default' => '1',
            ]
        );

        $this->end_controls_section();//End Select Style


	    //===================== Location Filter =========================//
	    $this->start_controls_section(
		    'sec_content', [
			    'label' => __('Content', 'listy-core'),
		    ]
	    );

	    $this->add_control(
			'sub_title',
			[
				'label' => esc_html__( 'Sub Title', 'listy-core' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'SOCIALLY RESPONSIBLE', 'listy-core' ),
			]
		);

        $this->add_control(
			'title',
			[
				'label' => esc_html__( 'Title', 'listy-core' ),
				'type' => \Elementor\Controls_Manager::TEXTAREA,
				'default' => esc_html__( 'Default title', 'listy-core' ),
			]
		);

        $this->add_control(
			'button',
			[
				'label' => esc_html__( 'Button', 'listy-core' ),
				'type' => \Elementor\Controls_Manager::TEXT,
				'default' => esc_html__( 'Learn More', 'listy-core' ),
			]
		);

        $this->add_control(
			'link',
			[
				'label' => esc_html__( 'Link', 'listy-core' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'listy-core' ),
				'options' => [ 'url', 'is_external', 'nofollow' ],
				'label_block' => true,
			]
		);

	    $this->end_controls_section(); //End Location Filter

    }


    /**
     * Name: elementor_style_control()
     * Desc: Register style content
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @listy
     * Author: spider-themes
     */
    public function elementor_style_control () {

		//===================== Section Title ===========================//
		$this->start_controls_section(
			'sec_style', [
				'label' => esc_html__( 'Content Style', 'listy-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_control(
			'sub_title_options',
			[
				'label' => esc_html__( 'Sub Title', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

		$this->add_control(
			'sub_title_color', [
				'label'     => esc_html__( 'Color', 'listy-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .li_subtitle' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(), [
				'name'     => 'sub_title_typography',
				'selector' => '{{WRAPPER}} .li_subtitle',
			]
		);

        $this->add_control(
			'title_options',
			[
				'label' => esc_html__( 'Title', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->add_control(
			'title_color', [
				'label'     => esc_html__( 'Color', 'listy-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .li_title' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(), [
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} .li_title',
			]
		);

        $this->add_responsive_control(
		    'title_margin', [
			    'label' => __( 'Margin', 'listy-core' ),
			    'type' => Controls_Manager::DIMENSIONS,
			    'size_units' => [ 'px', '%', 'em' ],
			    'selectors' => [
				    '{{WRAPPER}} .li_title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

        $this->add_control(
			'button_options',
			[
				'label' => esc_html__( 'Button', 'textdomain' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);

        $this->add_control(
			'button_color', [
				'label'     => esc_html__( 'Color', 'listy-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .li_button' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(), [
				'name'     => 'button_typography',
				'selector' => '{{WRAPPER}} .li_button',
			]
		);

        $this->add_control(
			'alignment',
			[
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'label' => esc_html__( 'Alignment', 'textdomain' ),
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'textdomain' ),
						'icon' => 'eicon-text-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'textdomain' ),
						'icon' => 'eicon-text-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'textdomain' ),
						'icon' => 'eicon-text-align-right',
					],
				],
				'default' => 'center',
			]
		);

		$this->end_controls_section(); // End Section Title


	    //===================== Section Background ===========================//
	    $this->start_controls_section(
		    'style_background', [
			    'label' => esc_html__( 'Background', 'listy-core' ),
			    'tab'   => Controls_Manager::TAB_STYLE,
			    'condition' => [
					'layout' => '1'
			    ]
		    ]
	    );

	    $this->add_responsive_control(
		    'sec_margin', [
			    'label' => __( 'Margin', 'listy-core' ),
			    'type' => Controls_Manager::DIMENSIONS,
			    'size_units' => [ 'px', '%', 'em' ],
			    'selectors' => [
				    '{{WRAPPER}} .li_card' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

	    $this->add_responsive_control(
		    'sec_padding', [
			    'label' => __( 'Padding', 'listy-core' ),
			    'type' => Controls_Manager::DIMENSIONS,
			    'size_units' => [ 'px', '%', 'em' ],
			    'selectors' => [
				    '{{WRAPPER}} .li_card' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
			    ],
		    ]
	    );

		$this->add_control(
            'border_radius',
            [
                'label' => esc_html__( 'Border Radius', 'landpagy-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .li_card_listy' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

		$this->add_control(
            'border_radiuss',
            [
                'label' => esc_html__( 'Border Radius', 'landpagy-core' ),
                'type' => Controls_Manager::DIMENSIONS,
                'size_units' => [ 'px', '%', 'em' ],
                'selectors' => [
                    '{{WRAPPER}} .li_card' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
                ],
            ]
        );

	    $this->add_group_control(
		    \Elementor\Group_Control_Background::get_type(), [
			    'name' => 'sec_bg_color',
			    'label' => __( 'Background', 'listy-core' ),
			    'types' => [ 'classic', 'gradient' ],
			    'selector' => '{{WRAPPER}} .li_card',
		    ]
	    );

		$this->end_controls_section(); //End Section Background


    }


    /**
     * Name: elementor_render()
     * Desc: Render widget output on the frontend.
     * Params: no params
     * Return: @void
     * Since: @1.0.0
     * Package: @listy
     * Author: spider-themes
     */
    protected function render() {
        $settings = $this->get_settings_for_display();
        extract($settings); //Array to variable conversation

        if ( ! empty( $settings['link']['url'] ) ) {
			$this->add_link_attributes( 'link', $settings['link'] );
		}

        //====== Template Parts
        include "template/card/card-{$settings['layout']}.php";

    }
}