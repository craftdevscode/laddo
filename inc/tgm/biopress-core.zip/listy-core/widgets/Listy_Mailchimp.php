<?php

namespace ListyCore\widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Image_hover
 * @package ListyCore\Widgets
 */
class Listy_Mailchimp extends Widget_Base {
	public function get_name() {
		return 'listy_mailchimp';
	}

	public function get_title() {
		return __( 'Mailchimp Form (Listy)', 'listy-core' );
	}

	public function get_icon() {
		return 'eicon-mailchimp';
	}

	public function get_script_depends() {
		return [ 'ajax-chimp' ];
	}

	public function get_categories() {
		return [ 'listy-elements' ];
	}

	public function get_keywords() {
		return [ 'Subscriber', 'Mailchimp', 'Form', 'Newsletter' ];
	}


	/**
	 * Name: register_controls()
	 * Desc: Register controls for these widgets
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	protected function register_controls() {
		$this->elementor_content_control();
		$this->elementor_style_control();
	}


	/**
	 * Name: elementor_content_control()
	 * Desc: Register content
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	public function elementor_content_control() {


		// ------------------------------ MailChimp form ------------------------------
		$this->start_controls_section(
			'form_settings', [
				'label' => __( 'Form settings', 'listy-core' ),
			]
		);

		$this->add_control(
			'email_placeholder', [
				'label'       => esc_html__( 'Email Placeholder', 'listy-core' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => 'Email Address',
			]
		);

		$this->add_control(
			'action_url', [
				'label'       => esc_html__( 'Action URL', 'listy-core' ),
				'description' => __( 'Enter here your MailChimp action URL. <a href="#" target="_blank"> How to </a>', 'listy-core' ),
				'type'        => Controls_Manager::TEXTAREA,
			]
		);

		$this->add_control(
			'submit_btn', [
				'label'       => esc_html__( 'Submit Button', 'listy-core' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => 'Subscribe',
			]
		);

		$this->end_controls_section(); //End Mailchimp

	}


	/**
	 * Name: elementor_style_control()
	 * Desc: Register style content
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	public function elementor_style_control() {

		//================================== Form Style ===================== //
		$this->start_controls_section(
			'form_style_sec', [
				'label' => __( 'Form Styling', 'listy-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_responsive_control(
			'form_padding',
			[
				'label'      => __( 'Padding', 'listy-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .listy_subscribe .form-control' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'form_border_radius',
			[
				'label'      => __( 'Border Radius', 'listy-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .listy_subscribe .form-control' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name'     => 'form_border',
				'label'    => __( 'Border', 'listy-core' ),
				'selector' => '{{WRAPPER}} .listy_subscribe .form-control',
			]
		);

		$this->add_control(
			'form_hover_text_color', [
				'label'     => __( 'Hover Border Color', 'listy-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .listy_subscribe .form-control:hover' => 'color: {{VALUE}};',
				],
				'condition' => [
					'border_border!' => '',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(), [
				'name'     => 'from_typo',
				'selector' => '{{WRAPPER}} .right-contant .cta-search .form-control',
			]
		);

		$this->add_control(
			'from_normal_text_color', [
				'label'     => __( 'Text Color', 'listy-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .right-contant .cta-search .form-control' => 'color: {{VALUE}};',
				]
			]
		);

		$this->add_control(
			'placeholder_text_color', [
				'label'     => __( 'Placeholder Text Color', 'listy-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .right-contant .cta-search .form-control::placeholder' => 'color: {{VALUE}};',
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(), [
				'name'           => 'form_bg_color',
				'label'          => esc_html__( 'Background', 'plugin-name' ),
				'types'          => [ 'classic', 'gradient' ],
				'exclude'        => [ 'image' ],
				'fields_options' => [
					'background' => [
						'default' => 'classic',
					],
					'color'      => [
						'dynamic' => [],
					],
					'color_b'    => [
						'dynamic' => [],
					],
				],
				'selector'       => '{{WRAPPER}} .listy_subscribe .form-control',
				'separator'      => 'before'
			]
		);

		$this->add_responsive_control(
			'spacing_btn_bottom', [
				'label'      => esc_html__( 'Space', 'plugin-name' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 500,
					],
					'%'  => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => '10',
				],
				'selectors'  => [
					'{{WRAPPER}} .listy_subscribe .form-group' => 'margin-bottom: {{SIZE}}{{UNIT}};',
				],
				'separator'  => 'before',
			]
		);

		$this->end_controls_section(); //End form Style


		//====================== Submit Button Style ========================//
		$this->start_controls_section(
			'submit_btn_style', [
				'label' => __( 'Submit Button', 'listy-core' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(), [
				'name'     => 'btn_typo',
				'selector' => '{{WRAPPER}} .__btn',
			]
		);

		$this->start_controls_tabs( 'btn_style_tabs' );

		//Normal Tabs
		$this->start_controls_tab(
			'btn_normal_tabs', [
				'label' => __( 'Normal', 'listy-core' ),
			]
		);

		$this->add_control(
			'btn_normal_text_color', [
				'label'     => __( 'Text Color', 'listy-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .__btn' => 'color: {{VALUE}};',
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(), [
				'name'           => 'btn_normal_bg_color',
				'label'          => esc_html__( 'Background', 'plugin-name' ),
				'types'          => [ 'classic', 'gradient' ],
				'exclude'        => [ 'image' ],
				'fields_options' => [
					'background' => [
						'default' => 'classic',
					],
					'color'      => [
						'dynamic' => [],
					],
					'color_b'    => [
						'dynamic' => [],
					],
				],
				'selector'       => '{{WRAPPER}} .__btn',
			]
		);

		$this->add_control(
			'btn_normal_border_color', [
				'label'     => __( 'Border Color', 'listy-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .__btn' => 'border-color: {{VALUE}};',
				]
			]
		);

		$this->end_controls_tab(); // End Normal Tabs

		//Hover Tabs
		$this->start_controls_tab(
			'btn_hover_tabs', [
				'label' => __( 'Hover', 'listy-core' ),
			]
		);

		$this->add_control(
			'btn_hover_text_color', [
				'label'     => __( 'Text Color', 'listy-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .__btn:hover' => 'color: {{VALUE}};',
				]
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(), [
				'name'           => 'btn_hover_bg_color',
				'label'          => esc_html__( 'Background', 'plugin-name' ),
				'types'          => [ 'classic', 'gradient' ],
				'exclude'        => [ 'image' ],
				'fields_options' => [
					'background' => [
						'default' => 'classic',
					],
					'color'      => [
						'dynamic' => [],
					],
					'color_b'    => [
						'dynamic' => [],
					],
				],
				'selector'       => '{{WRAPPER}} .__btn:hover',
			]
		);

		$this->add_control(
			'btn_hover_border_color', [
				'label'     => __( 'Border Color', 'listy-core' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .__btn:hover' => 'border-color: {{VALUE}};',
				]
			]
		);

		$this->end_controls_tab();//End Hover Tabs
		$this->end_controls_tabs(); // End Button Tabs


		$this->add_responsive_control(
			'btn_margin', [
				'label'      => __( 'Margin', 'listy-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .__btn' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator'  => 'before',
			]
		);

		$this->add_responsive_control(
			'btn_padding',
			[
				'label'      => __( 'Padding', 'listy-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .__btn' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator'  => 'after',
			]
		);

		$this->add_responsive_control(
			'btn_border_radius', [
				'label'      => __( 'Border Radius', 'listy-core' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .__btn' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(), [
				'name'     => 'btn_border',
				'label'    => __( 'Border', 'listy-core' ),
				'selector' => '{{WRAPPER}} .__btn',
			]
		);

		$this->add_control(
			'btn_height', [
				'label'      => esc_html__( 'Height', 'plugin-name' ),
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range'      => [
					'px' => [
						'min' => 0,
						'max' => 100,
					],
					'%'  => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default'    => [
					'unit' => 'px',
					'size' => '',
				],
				'selectors'  => [
					'{{WRAPPER}} .__btn' => 'height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_section(); //End submit button style

	}


	/**
	 * Name: elementor_render()
	 * Desc: Render widget output on the frontend.
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		extract( $settings ); // extract all settings variables

		?>
        <div class="right-contant">
            <form action="javascript:void(0)" class="mailchimp listy_subscribe cta-search-form"
                  data-action-url="<?php echo esc_url( $settings['action_url'] ); ?>" method="post">
                <div class="d-flex cta-search">
                    <input type="email" class="form-control memail" name="email"
                           placeholder="<?php echo esc_attr( $settings['email_placeholder'] ) ?>">
                    <button class="btn-Subscribe __btn" type="submit">
						<?php echo esc_html( $settings['submit_btn'] ); ?>
                    </button>
                </div>
                <p class="mchimp-errmessage text-center mt-3" style="display: none;"></p>
                <p class="mchimp-sucmessage text-center mt-3" style="display: none;"></p>
            </form>
        </div>
		<?php

	}
}