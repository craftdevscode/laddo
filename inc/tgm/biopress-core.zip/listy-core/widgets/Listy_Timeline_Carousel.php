<?php

namespace ListyCore\Widgets;

// Exit if accessed directly
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Image_hover
 * @package ListyCore\Widgets
 */
class Listy_Timeline_Carousel extends \Elementor\Widget_Base {

	public function get_name() {
		return 'listy_timeline_carousel';
	}

	public function get_title() {
		return __( 'Timeline Carousel (Listy)', 'listy-core' );
	}

	public function get_icon() {
		return 'eicon-time-line';
	}

	public function get_style_depends() {
		return [ 'slick', 'slick-theme' ];
	}

	public function get_script_depends() {
		return [ 'jquery-ui', 'slick' ];
	}

	public function get_categories() {
		return [ 'listy-elements' ];
	}


	/**
	 * Name: register_controls()
	 * Desc: Register controls for these widgets
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	protected function register_controls() {
		$this->elementor_content_control();
		$this->elementor_style_control();
	}


	/**
	 * Name: elementor_content_control()
	 * Desc: Register content
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	public function elementor_content_control() {

		//============================== Timeline Carousel ===============================//
		$this->start_controls_section(
			'testimonials_sec', [
				'label' => __( 'Timeline Carousel', 'listy-core' ),
			]
		);

		//================ Testimonials 01
		$timeline = new \Elementor\Repeater();
		$timeline->add_control(
			'image', [
				'label' => __( 'Image', 'listy-core' ),
				'type'  => \Elementor\Controls_Manager::MEDIA,
			]
		);

		$timeline->add_control(
			'title', [
				'label'       => __( 'Title', 'listy-core' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => 'Birth of a Listy startup'
			]
		);

		$timeline->add_control(
			'content', [
				'label' => __( 'Content', 'listy-core' ),
				'type'  => \Elementor\Controls_Manager::TEXTAREA,
			]
		);

		$timeline->add_control(
			'date', [
				'label'   => __( 'Date', 'listy-core' ),
				'type'    => \Elementor\Controls_Manager::TEXT,
				'default' => '2013'
			]
		);

		$this->add_control(
			'timeline_carousels', [
				'label'         => __( 'Add Timeline', 'listy-core' ),
				'type'          => \Elementor\Controls_Manager::REPEATER,
				'fields'        => $timeline->get_controls(),
				'title_field'   => '{{{ title }}}',
				'prevent_empty' => false,
			]
		);

		$this->end_controls_section();

	}


	/**
	 * Name: elementor_style_control()
	 * Desc: Register style content
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	public function elementor_style_control() {


		$this->start_controls_section(
			'tab_style', [
				'label' => __( 'Style', 'listy-core' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);


		$this->add_responsive_control(
			'content_padding',
			[
				'label'      => esc_html__( 'Content Padding', 'listy-core' ),
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .history-item .item-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'separator'  => 'before',
			]
		);


		$this->add_control(
			'title_color', [
				'label'     => __( 'Title Color', 'listy-core' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .history-item .item-title' => 'color: {{VALUE}};',
				],
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'      => 'title_typography',
				'label'     => __( 'Title Typography', 'listy-core' ),
				'selector'  => '{{WRAPPER}} .history-item .item-content .item-title',
				'separator' => 'after',

			]
		);


		$this->add_control(
			'content_color', [
				'label'     => __( 'Content Color', 'listy-core' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .history-item .item-para' => 'color: {{VALUE}};',
				],
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'      => 'content_typography',
				'label'     => __( 'Content Typography', 'listy-core' ),
				'selector'  => '{{WRAPPER}} .history-item .item-content .item-para',
				'separator' => 'after',

			]
		);


		$this->add_control(
			'year_color', [
				'label'     => __( 'Year Color', 'listy-core' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .history-item .date' => 'color: {{VALUE}};',
				],
				'separator' => 'before',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'      => 'year_typography',
				'label'     => __( 'Year Typography', 'listy-core' ),
				'selector'  => '{{WRAPPER}} .history-item .date',
				'separator' => 'after',

			]
		);

		$this->end_controls_section();

	}


	/**
	 * Name: elementor_render()
	 * Desc: Render widget output on the frontend.
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		extract( $settings ); //Array to variable conversation

		?>
        <div class="history-wrapper">
			<?php
			if ( ! empty( $timeline_carousels ) ) {
				foreach ( $timeline_carousels as $item ) {
					?>
                    <div class="history-item">
                        <div class="item-img">
							<?php echo wp_get_attachment_image( $item['image']['id'], 'listy_310x190' ) ?>
                        </div>
                        <div class="item-content">
							<?php
							if ( ! empty( $item['title'] ) ) { ?>
                                <h4 class="item-title title"><?php echo esc_html( $item['title'] ) ?></h4>
								<?php
							}
							if ( ! empty( $item['content'] ) ) { ?>
                                <p class="item-para content"><?php echo esc_html( $item['content'] ) ?></p>
								<?php
							}
							if ( ! empty( $item['date'] ) ) { ?>
                                <span class="date"><?php echo esc_html( $item['date'] ) ?></span>
								<?php
							}
							?>
                        </div>
                    </div>
					<?php
				}
			}
			?>
        </div>
        <div class="history-scrollbar"></div>
		<?php
	}
}