<?php

namespace ListyCore\Widgets;

use Elementor\Controls_Manager;
use Elementor\Widget_Base;
use WP_Query;

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Image_hover
 * @package ListyCore\Widgets
 */
class Listy_Jobs extends Widget_Base {

	public function get_name() {
		return 'listy_jobs';
	}

	public function get_title() {
		return __( 'Listy Jobs (Theme)', 'listy-core' );
	}

	public function get_icon() {
		return 'eicon-document-file';
	}

	public function get_categories() {
		return [ 'listy-elements' ];
	}

	/**
	 * Name: register_controls()
	 * Desc: Register controls for these widgets
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	protected function register_controls() {
		$this->elementor_content_control();
		$this->elementor_style_control();
	}

	/**
	 * Name: elementor_content_control()
	 * Desc: Register content
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	public function elementor_content_control() {


		//=============================== Select Style =================================//
		$this->start_controls_section(
			'select_style', [
				'label' => __( 'Style', 'listy-core' ),
			]
		);

		$this->add_control(
			'style', [
				'label'   => __( 'Style', 'listy-core' ),
				'type'    => Controls_Manager::SELECT,
				'default' => '1',
				'options' => [
					'1' => __( '01: Job List', 'listy-core' ),
					'2' => __( '02: Featured Job', 'listy-core' ),
				],
			]
		);

		$this->end_controls_section(); // End Style


		//============================= Filter Options ================================//
		$this->start_controls_section(
			'filter_sec', [
				'label' => __( 'Filter', 'listy-core' ),
			]
		);

		// $this->add_control(
		// 	'cats', [
		// 		'label'       => esc_html__( 'Category', 'listy-core' ),
		// 		'description' => esc_html__( 'Display job by categories', 'listy-core' ),
		// 		'type'        => Controls_Manager::SELECT2,
		// 		'options'     => Listy_Core_Helper()->get_the_categories( 'job_cat' ),
		// 		'multiple'    => true,
		// 		'label_block' => true,
		// 		'condition'   => [
		// 			'style' => [ '1', '2' ]
		// 		]
		// 	]
		// );

		$this->add_control(
			'cats', [
				'label'       => esc_html__( 'Category', 'banca-core' ),
				'description' => esc_html__( 'Display job by categories', 'banca-core' ),
				'type'        => Controls_Manager::SELECT2,
				'options'     => listy_cat_array( 'job_cat' ),
				'multiple'    => true,
				'label_block' => true,
			]
		);

		$this->add_control(
			'show_count', [
				'label'   => esc_html__( 'Show Posts Count', 'listy-core' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 4
			]
		);

		$this->add_control(
			'order', [
				'label'   => esc_html__( 'Order', 'listy-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'ASC'  => 'ASC',
					'DESC' => 'DESC'
				],
				'default' => 'ASC'
			]
		);

		$this->add_control(
			'orderby', [
				'label'   => esc_html__( 'Order By', 'listy-core' ),
				'type'    => Controls_Manager::SELECT,
				'options' => [
					'none'   => 'None',
					'ID'     => 'ID',
					'author' => 'Author',
					'title'  => 'Title',
					'name'   => 'Name (by post slug)',
					'date'   => 'Date',
					'rand'   => 'Random',
				],
				'default' => 'none'
			]
		);

		$this->add_control(
			'title_length', [
				'label'   => esc_html__( 'Excerpt Word Length', 'listy-core' ),
				'type'    => Controls_Manager::NUMBER,
				'default' => 6,
			]
		);

		$this->add_control(
			'excerpt_length', [
				'label' => esc_html__( 'Excerpt Word Length', 'listy-core' ),
				'type'  => Controls_Manager::NUMBER,
			]
		);

		$this->add_control(
			'exclude', [
				'label'       => esc_html__( 'Exclude Job', 'listy-core' ),
				'description' => esc_html__( 'Enter the job post IDs to hide/exclude. Input the multiple ID with comma separated', 'listy-core' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
			]
		);

		// View Button
		$this->add_control(
			'btn_title', [
				'label'       => esc_html__( 'Button Title', 'listy-core' ),
				'type'        => Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => 'Apply Now',
			]
		);

		$this->end_controls_section(); // End Job Filters

	}

	/**
	 * Name: elementor_style_control()
	 * Desc: Register style
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	public function elementor_style_control() {


	}

	/**
	 * Name: elementor_render()
	 * Desc: Render widget
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		extract( $settings ); //Array to Variable Conversation

		$args = [
			'post_type'   => 'job',
			'post_status' => 'publish',
		];
		if ( ! empty( $show_count ) ) {
			$args['posts_per_page'] = $show_count;
		}
		if ( ! empty( $order ) ) {
			$args['order'] = $order;
		}
		if ( ! empty( $orderby ) ) {
			$args['orderby'] = $orderby;
		}
		if ( ! empty( $exclude ) ) {
			$args['post__not_in'] = $exclude;
		}
		if ( ! empty( $cats ) ) {
			$args['tax_query'] = [
				[
					'taxonomy' => 'job_cat',
					'field'    => 'slug',
					'terms'    => $cats

				]
			];
		}

		/*if ( $style == '2' ) {
			$args['meta_query'] = [
				[
					'key'     => 'featured',
					'value'   => 'yes',
					'compare' => '='
				]
			];
		}*/

		$jobs = new WP_Query( $args );

		// Include File Path
		include "template/jobs/job-{$settings['style']}.php";

	}
}