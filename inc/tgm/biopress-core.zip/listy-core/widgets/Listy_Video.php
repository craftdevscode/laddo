<?php

namespace ListyCore\Widgets;

// Exit if accessed directly
use Elementor\Controls_Manager;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Image_hover
 * @package ListyCore\Widgets
 */
class Listy_Video extends \Elementor\Widget_Base {

	public function get_name() {
		return 'listy_video';
	}

	public function get_title() {
		return __( 'Video (Listy)', 'listy-core' );
	}

	public function get_icon() {
		return 'eicon-video-camera';
	}

	public function get_style_depends() {
		return [ 'fancybox' ];
	}

	public function get_script_depends() {
		return [ 'fancybox' ];
	}

	public function get_categories() {
		return [ 'listy-elements' ];
	}

	/**
	 * Name: register_controls()
	 * Desc: Register controls for these widgets
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	protected function register_controls() {
		$this->elementor_content_control();
		$this->elementor_style_control();
	}


	/**
	 * Name: elementor_content_control()
	 * Desc: Register content
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	public function elementor_content_control() {

		//=========================== Featured Video ============================//
		$this->start_controls_section(
			'featured_video_sec', [
				'label' => __( 'Featured Video', 'listy-core' ),
			]
		);

		$this->add_control(
			'video_url', [
				'label'       => __( 'Video URL', 'listy-core' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
				'label_block' => true,
				'default'     => '#'
			]
		);

		$this->add_control(
			'bg_img', [
				'label'   => __( 'Background Image', 'listy-core' ),
				'type'    => \Elementor\Controls_Manager::MEDIA,
				'default' => [
					'url' => \Elementor\Utils::get_placeholder_image_src(),
				],
			]
		);

		$this->end_controls_section(); //End Featured Video
	}


	/**
	 * Name: elementor_style_control()
	 * Desc: Register style content
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	public function elementor_style_control() {

	}

	/**
	 * Name: elementor_render()
	 * Desc: Render widget output on the frontend.
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		extract( $settings ); //Array to variable conversation

		?>
        <section class="banner-about-2-area p-0">
            <div class="banner-video">
				<?php echo ! empty( $bg_img['id'] ) ? wp_get_attachment_image( $bg_img['id'], 'full', '', [ 'class' => 'banner-img' ] ) : '' ?>
                <div class="banner-shape"></div>
                <div class="banner-btn">
                    <a class="play-btn" href="<?php echo esc_url( $settings['video_url'] ) ?>" data-fancybox></a>
                </div>
            </div>
        </section>
		<?php

	}
}