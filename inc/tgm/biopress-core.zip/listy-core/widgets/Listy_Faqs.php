<?php

namespace ListyCore\Widgets;


// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Class Gallery
 * @package ListyCore\Widgets
 */
class Listy_Faqs extends \Elementor\Widget_Base {

	public function get_name() {
		return 'listy_faqs';
	}

	public function get_title() {
		return __( 'FAQs (Theme)', 'listy-core' );
	}

	public function get_icon() {
		return 'eicon-post-content';
	}

	public function get_categories() {
		return [ 'listy-elements' ];
	}

	/**
	 * Name: register_controls()
	 * Desc: Register controls for these widgets
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	protected function register_controls() {
		$this->elementor_content_control();
		$this->elementor_style_control();
	}


	/**
	 * Name: elementor_content_control()
	 * Desc: Register content
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	public function elementor_content_control() {


		//============================= Select Preset ==================================//
		$this->start_controls_section(
			'sec_layout', [
				'label' => esc_html__( 'Preset Skins', 'listy-core' ),
			]
		);

		$this->add_control(
			'layout', [
				'label'   => esc_html__( 'Layout', 'listy-core' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'1' => esc_html__( '01: Vertical Tabs', 'listy-core' ),
				],
				'default' => '1',
			]
		);

		$this->end_controls_section();//End Select Style


		//================================ Query Filter ============================//
		$this->start_controls_section(
			'portfolio_filter', [
				'label' => __( 'Filter', 'listy-core' ),
			]
		);

		$this->add_control(
			'cats', [
				'label'       => esc_html__( 'Categories', 'listy-core' ),
				'description' => esc_html__( 'Display portfolios by categories', 'listy-core' ),
				'type'        => \Elementor\Controls_Manager::SELECT2,
				'options'     => Listy_Core_Helper()->get_the_categories( 'faq_cat' ),
				'label_block' => true,
				'multiple'    => true,
			]
		);

		$this->add_control(
			'show_count', [
				'label'   => esc_html__( 'Show count', 'listy-core' ),
				'type'    => \Elementor\Controls_Manager::NUMBER,
				'default' => 9
			]
		);

		$this->add_control(
			'order', [
				'label'       => esc_html__( 'Order', 'listy-core' ),
				'description' => esc_html__( '‘ASC‘ – ascending order from lowest to highest values (1, 2, 3; a, b, c). ‘DESC‘ – descending order from highest to lowest values (3, 2, 1; c, b, a).', 'listy-core' ),
				'type'        => \Elementor\Controls_Manager::SELECT,
				'options'     => [
					'ASC'  => 'ASC',
					'DESC' => 'DESC'
				],
				'default'     => 'ASC'
			]
		);

		$this->add_control(
			'orderby', [
				'label'   => esc_html__( 'Order By', 'listy-core' ),
				'type'    => \Elementor\Controls_Manager::SELECT,
				'options' => [
					'none'          => 'None',
					'ID'            => 'ID',
					'author'        => 'Author',
					'title'         => 'Title',
					'name'          => 'Name (by post slug)',
					'date'          => 'Date',
					'rand'          => 'Random',
					'comment_count' => 'Comment Count',
				],
				'default' => 'none'
			]
		);

		$this->add_control(
			'exclude', [
				'label'       => esc_html__( 'Exclude FAQs', 'listy-core' ),
				'description' => esc_html__( 'Enter the faqs post ID to hide. Input the multiple ID with comma separated', 'listy-core' ),
				'type'        => \Elementor\Controls_Manager::TEXT,
			]
		);

		$this->end_controls_section(); //End Query filter

	}


	/**
	 * Name: elementor_style_control()
	 * Desc: Register style content
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	public function elementor_style_control() {

		//============================= Style Section ==================================//
		$this->start_controls_section(
			'style_section',
			[
				'label' => esc_html__( 'Style Section', 'textdomain' ),
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

		//==== Tab Style
		$this->add_control(
			'tab_style',
			[
				'label'     => esc_html__( 'Tab Style', 'textdomain' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'after',
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'tab_typo',
				'selector' => '{{WRAPPER}} .faq-tag-widget .nav-link',
			]
		);
		$this->add_control(
			'tab_color',
			[
				'label'     => esc_html__( 'Color', 'textdomain' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .faq-area .faq-tag-widget .nav-link' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_control(
			'tab_hover_color',
			[
				'label'     => esc_html__( 'Hover Color', 'textdomain' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .faq-tag-widget .nav-link.active, .faq-tag-widget .nav-link:hover' => 'color: {{VALUE}}',
				],
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name'     => 'tab_background',
				'types'    => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .faq-tag-widget .nav-link',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'name'     => 'tab_hover_background',
				'types'    => [ 'classic', 'gradient', 'video' ],
				'selector' => '{{WRAPPER}} .faq-tag-widget .nav-link.active, .faq-tag-widget .nav-link:hover',
			]
		);///
		$this->add_control(
			'title_style',
			[
				'label'     => esc_html__( 'Title Style', 'textdomain' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'after',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'title_typography',
				'selector' => '{{WRAPPER}} ._title',
			]
		);
		$this->add_control(
			'title_color',
			[
				'label'     => esc_html__( 'Color', 'textdomain' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} ._title' => 'color: {{VALUE}}',
				],
			]
		); ///
		$this->add_control(
			'content_style',
			[
				'label'     => esc_html__( 'Content Style', 'textdomain' ),
				'type'      => \Elementor\Controls_Manager::HEADING,
				'separator' => 'after',
			]
		);
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name'     => 'content_typography',
				'selector' => '{{WRAPPER}} .single-faq p',
			]
		);
		$this->add_control(
			'content_color',
			[
				'label'     => esc_html__( 'Color', 'textdomain' ),
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .single-faq p' => 'color: {{VALUE}}',
				],
			]
		); ///

		$this->end_controls_section();
	}


	/**
	 * Name: elementor_render()
	 * Desc: Render widget output on the frontend.
	 * Params: no params
	 * Return: @void
	 * Since: @1.0.0
	 * Package: @listy
	 * Author: spider-themes
	 */
	protected function render() {
		$settings = $this->get_settings_for_display();
		extract( $settings ); //Array to variable conversation

		$cats = get_terms( array(
			'taxonomy'   => 'faq_cat',
			'hide_empty' => true
		) );

		//==== Include Template Parts
		include "template/faqs/faq-{$settings['layout']}.php";

	}
}