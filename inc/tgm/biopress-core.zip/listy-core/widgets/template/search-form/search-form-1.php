<section class="banner-area dffdsasfsdfsdf">
	<div class="container">
		<div class="row">
			<div class="offset-lg-2 col-lg-8 text-center">
				<h1 class="banner-title"><?php echo $settings['search_title']; ?></h1>
				<p class="banner-subtitle">
				<?php echo $settings['search_content']; ?>
				</p>
				<div class="listing-search-form mt-40">
					<form action="#">
						<div class="d-flex">
							<div class="input-group">
								<span class="input-group-text">What?</span>
								<input type="text" class="form-control" placeholder="Ex: food, service, barber, hotel">
							</div>
							<div class="divider"></div>
							<div class="input-group">
								<span class="input-group-text">Where?</span>
								<input type="text" class="form-control" placeholder="Your City">
								<span class="input-group-text">
                                    <img src="./assets/img/icons/icon-01.svg" alt="Icon">
                                </span>
							</div>
							<button class="btn" type="submit"><?php echo $settings['search_button']; ?></button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</section>