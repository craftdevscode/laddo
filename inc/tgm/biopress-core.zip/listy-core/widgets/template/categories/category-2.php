<div class="row gx-sm-4 gx-2 ">
    <?php
    if ( is_array( $categories) ) {
        foreach ($categories as $index => $category) {
            $meta = get_term_meta($category->term_id, 'listy_listing_cat', true); //false returns an array
            $term_image = !empty($meta['cat_img']) ? $meta['cat_img'] : '';
            $cat_link = get_term_link( $category->slug, 'listing_cat' );
            $colum = $index == 0 ? 'col-lg-6' : 'col-lg-3 col-6';
            ?>
            <div class="<?php echo esc_attr($colum) ?> wow fadeInUp">
                <a href="<?php echo esc_url($cat_link) ?>" class="cities-feature-widget variant-2">
                    <?php
                    if ( !empty($term_image['id']) ) {
                        echo wp_get_attachment_image($term_image['id'], 'full', '', [ 'class' => 'city-img' ]);
                    }
                    ?>
                    <div class="content text-center">
                        <h4 class="cities-title"><?php echo esc_html($category->name) ?></h4>
                        <p class="cities-listing"><?php printf( _n( '%s Listing', '%s Listings', $category->count, 'listy-core' ), $category->count ); ?></p>
                    </div>
                </a>
            </div>
            <?php

        }
    }
    ?>
</div>