<section class="explore-2-area wow fadeInUp">
    <div class="explore-item row">
		<?php
		if ( ! empty( $categories ) ) {
			foreach ( $categories as $index => $category ) {
				$meta       = get_term_meta( $category->term_id, 'listy_listing_cat', true );
				$term_image = ! empty( $meta['cat_img'] ) ? $meta['cat_img'] : '';
				$cat_link   = get_term_link( $category->slug, 'listing_cat' );
				switch ( $index ) {
					case 0:
						$img_size     = 'listy_196x226';
						$column_class = 'col-xl-2 col-lg-3 col-md-4 double-place-column';
						break;
					case 1:
						$img_size     = 'listy_636x484';
						$column_class = 'col-xl-6 col-lg-8 col-md-8 h100-widget';
						break;
					case 2:
						$img_size     = 'listy_416x227';
						$column_class = 'col-xl-4 col-lg-5 col-md-6 h50-widget double-place-column';
						break;
					case 3:
						$img_size     = 'listy_196x226';
						$column_class = 'col-xl-2 col-lg-3 col-md-3 double-place-column';
						break;
					case 4:
						$img_size     = 'listy_196x226';
						$column_class = 'col-xl-2 col-lg-3 col-md-3 double-place-column';
						break;
					case 5:
						$img_size     = 'listy_416x484';
						$column_class = 'col-xl-4 col-lg-5 col-md-6 h100-widget';
						break;
					case 6:
						$img_size     = 'listy_196x226';
						$column_class = 'col-xl-2 col-lg-3 col-md-3 double-place-column';
						break;
					case 7:
						$img_size     = 'listy_196x226';
						$column_class = 'col-xl-2 col-lg-3 col-md-3 double-place-column';
						break;
				}
				?>
                <div class="<?php echo esc_attr( $column_class ) ?>">
                    <div class="place">
						<?php
						if ( ! empty( $term_image['id'] ) ) {
							echo wp_get_attachment_image( $term_image['id'], $img_size );
						}
						?>
                        <a href="<?php echo get_category_link( $category->term_id ) ?>"
                           class="btn btn-brand"><?php echo esc_html( $category->name ) ?></a>
                    </div>

					<?php
					if ( $index == 0 || $index == 2 || $index == 3 || $index == 4 || $index == 6 || $index == 7 ) {
						?>
                        <div class="place">
							<?php
							if ( ! empty( $term_image['id'] ) ) {
								echo wp_get_attachment_image( $term_image['id'], $img_size );
							}
							?>
                            <a href="<?php echo get_category_link( $category->term_id ) ?>"
                               class="btn btn-brand"><?php echo esc_html( $category->name ) ?></a>
                        </div>
						<?php
					}
					?>
                </div>
				<?php
			}
		}
		?>
    </div>
</section>