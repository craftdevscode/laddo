<section class="categoris-area __listy_sec">
    <div class="row position-relative gy-xl-0 gy-4" id="adRow01">
		<?php
		$delay_time = 0.1;
		if ( is_array( $categories ) ) {
			foreach ( $categories as $index => $category ) {
				$meta       = get_term_meta( $category->term_id, 'listy_listing_cat', true ); //false returns an array
				$term_image = ! empty( $meta['cat_img'] ) ? $meta['cat_img'] : '';
				$unique_id  = wp_unique_id( 'listy-cat-' );
				if ( $category->parent == 0 ) {
					?>
                    <div class="col-xl-<?php echo esc_attr( $column ) ?> col-md-4 col-sm-6 category-list-parent wow fadeInRight"
                         data-wow-delay="<?php echo esc_attr( $delay_time ) ?>s">
                        <div class="categories-item text-center">
							<?php
							if ( ! empty( $term_image['id'] ) ) {
								echo wp_get_attachment_image( $term_image['id'], 'full', '', [ 'class' => 'mx-auto' ] );
							}
							?>
                            <h4 class="categories-title"><?php echo esc_html( $category->name ) ?></h4>
                            <a class="ad-click collapsed" data-bs-toggle="collapse"
                               href="#adExample-<?php echo esc_attr( $unique_id ); ?>" role="button"
                               aria-expanded="false" aria-controls="adExample-<?php echo esc_attr( $unique_id ); ?>">
								<?php echo esc_html( $category->count ) ?> <?php esc_html_e( 'Ads', 'listy-core' ); ?>
                                <i class="las la-angle-up"></i>
                            </a>
                        </div>
						<?php
						$sub_categories = get_categories( array(
							'taxonomy'   => 'listing_cat',
							'parent'     => $category->term_id,
							'hide_empty' => false,
						) );

						if ( is_array( $sub_categories ) ) {
							?>
                            <div class="catagorized-option-widget container collapse"
                                 id="adExample-<?php echo esc_attr( $unique_id ); ?>" data-bs-parent="#adRow01">
                                <div class="box">
                                    <h6><?php esc_html_e( 'View all in ' . esc_html( $category->name ), 'listy-core' ); ?></h6>
                                    <div class="row">
                                        <div class="col-lg-12">
                                            <ul>
												<?php
												foreach ( $sub_categories as $sub_category ) {
													if ( $sub_category->parent == $category->term_id ) {
														?>
                                                        <li>
                                                            <a href="<?php echo get_category_link( $sub_category->term_id ) ?>">
                                                                <i class="las la-caret-right"></i>
																<?php echo esc_html( $sub_category->name ) ?>
                                                            </a>
                                                        </li>
														<?php
													}
												}
												?>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
							<?php
						}
						?>
                    </div>
					<?php
				}
				$delay_time += 0.2;
			}
		}
		?>
    </div>
</section>