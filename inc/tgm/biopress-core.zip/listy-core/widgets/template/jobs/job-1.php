<section class="feature-jobs">
    <div class="feature-job-tab">
        <ul class="feature-job-list list-unstyled">
			<?php
			$data_wow_delay = 0.1;
			if ( $jobs->have_posts() ) :
				while ( $jobs->have_posts() ) : $jobs->the_post();
					?>
                    <li class="mt-0">
                        <div class="single-feature-job wow fadeInUp" data-wow-delay="0.1s">
                            <h6 class="job-title">
                                <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute() ?>">
									<?php echo Listy_Core_Helper()->get_the_title_length( $settings, 'title_length' ) ?>
                                </a>
                            </h6>
                            <div class="d-flex flex-wrap">
                                <div class="job-location me-3"><i class="las la-map-marker-alt"></i>
									<?php echo Listy_Core_Helper()->get_the_first_taxonomy( 'job_location' ); ?>
                                </div>
                                <div class="job-catagory">
                                    <span><?php echo Listy_Core_Helper()->get_the_first_taxonomy( 'job_cat' ); ?></span>
                                    | <?php echo Listy_Core_Helper()->get_the_first_taxonomy( 'job_type' ); ?>
                                </div>
                            </div>
                        </div>
                    </li>
					<?php
					$data_wow_delay = $data_wow_delay + 0.2;
				endwhile;
				wp_reset_postdata();
			endif;
			?>
        </ul>
    </div>
</section>