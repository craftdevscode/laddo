<section class="article-area">
    <div class="row">
		<?php
		$delay_time = 0.1;
		while ( $posts->have_posts() ) : $posts->the_post();
			?>
            <div class="col-lg-4 col-md-6 col-sm-10 mx-auto wow fadeInUp"
                 data-wow-delay="<?php echo esc_attr( $delay_time ) ?>s">
                <div class="article-widget pb-40">
                    <a href="<?php the_permalink(); ?>">
						<?php the_post_thumbnail( 'listy_510x440' ); ?>
                    </a>
                    <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute() ?>">
                        <h5 class="article-title hover-underlibne pt-30 mb-20">
							<?php echo Listy_Core_Helper()->get_the_title_length( $settings, 'title_length' ) ?>
                        </h5>
                    </a>
                    <div class="article-sub-item">
						<?php echo Listy_Core_Helper()->get_the_author_avatar( 'user_name', 30 ) ?>
                        <a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ) ?>">
							<?php echo get_the_author_meta( 'display_name' ) ?>
                        </a>
                        <span class="article-date">
                            <i class="las la-calendar-week"></i>
                            <?php echo get_the_time( get_option( 'date_format' ) ) ?>
                        </span>
                    </div>
                    <div class="left-caption">
                        <p><?php echo Listy_Core_Helper()->get_the_first_taxonomy() ?></p>
                    </div>
                </div>
            </div>
			<?php
			$delay_time += 0.2;
		endwhile;
		wp_reset_postdata();
		?>
    </div>
</section>