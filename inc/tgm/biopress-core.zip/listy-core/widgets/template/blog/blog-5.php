<section class="doc_blog_grid_area">
    <div class="blog_grid_inner">
        <div class="container">
            <ul class="nav blog_tab">
				<?php
				if ( ! empty( $settings['cats'] ) ) {
					foreach ( $settings['cats'] as $index => $cat ) {
						$cat                      = get_term( $cat, 'category' );
						$tab_count                = $index + 1;
						$tab_category_setting_key = $this->get_repeater_setting_key( 'tab_li', '', $index );
						$active                   = $tab_count == 1 ? ' active' : '';
						$this->add_render_attribute( $tab_category_setting_key, [
							'class'          => 'nav-link' . $active,
							'data-bs-toggle' => 'tab',
							'href'           => '#' . $cat->slug,
						] );
						?>
                        <li class="nav-item">
                            <a <?php echo $this->get_render_attribute_string( $tab_category_setting_key ); ?>>
								<?php echo esc_html( $cat->name ) ?>
                            </a>
                        </li>
						<?php
					}
				}
				?>
            </ul>
        </div>
    </div>
    <div class="container">
        <div class="row blog_grid_tab">
            <div class="tab-content">
				<?php
				foreach ( $settings['cats'] as $index => $cat ) {
					$cat                     = get_term( $cat, 'category' );
					$tab_count               = $index + 1;
					$tab_content_setting_key = $this->get_repeater_setting_key( 'tab_content', '', $index );
					$show_active             = $tab_count == 1 ? ' show active' : '';
					$this->add_render_attribute( $tab_content_setting_key, [
						'class' => 'tab-pane fade pt-0' . $show_active,
						'id'    => $cat->slug,
						'role'  => 'tabpanel'
					] );
					?>
                    <div <?php echo $this->get_render_attribute_string( $tab_content_setting_key ); ?>>
                        <div class="row g-4">
							<?php
							$blog_post = new WP_Query( array(
								'post_type'      => 'post',
								'posts_per_page' => - 1,
								'order'          => ! empty( $settings['order'] ) ? $settings['order'] : '',
								'tax_query'      => array(
									array(
										'taxonomy' => 'category',
										'field'    => 'slug',
										'terms'    => $cat->slug,
									),
								),
							) );
							while ( $blog_post->have_posts() ) : $blog_post->the_post();
								?>
                                <div class="col-lg-4 col-sm-6">
                                    <div class="blog-widget wow fadeInUp bs-sm mb-35">
										<?php the_post_thumbnail( 'listy_380x220' ); ?>
                                        <div class="blog-content">
                                            <p class="blog-text dot-sep">
                                                <i class="las la-tag"></i>
												<?php echo Listy_Core_Helper()->get_the_first_taxonomy() ?>
                                                <span class="sep"><?php echo Listy_Core_Helper()->get_the_reading_time() ?></span>
                                            </p>
                                            <a href="<?php the_permalink(); ?>">
                                                <h5 class="__title"><?php echo Listy_Core_Helper()->get_the_title_length( $settings, 'title_length' ) ?></h5>
                                            </a>
                                            <div class="blog-sub-text">
												<?php echo Listy_Core_Helper()->get_the_author_avatar( 'user_name', 30 ) ?>
                                                <a href="javascript:void(0)"><?php echo get_the_author_meta( 'display_name' ) ?></a>
                                                <i class="las la-calendar"></i>
                                                <span><?php echo get_the_time( get_option( 'date_format' ) ) ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
							<?php
							endwhile;
							wp_reset_postdata();
							?>
                        </div>
                    </div>
					<?php
				}
				?>
            </div>
        </div>
    </div>
</section>