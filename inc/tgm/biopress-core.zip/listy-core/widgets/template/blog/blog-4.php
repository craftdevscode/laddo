<section class="blog_top_post_area">
	<?php
	while ( $posts->have_posts() ) : $posts->the_post();
		if ( is_sticky() ) {
			?>
            <div class="row blog_top_post flex-row-reverse shadow">
                <div class="col-lg-7 p_top_img">
					<?php the_post_thumbnail( 'listy_750x470', array( 'class' => 'p_img' ) ); ?>
                </div>
                <div class="col-lg-5 p-0">
                    <div class="b_top_post_content">
                        <div class="post_tag">
                            <a href="javascript:void(0)">
								<?php echo Listy_Core_Helper()->get_the_reading_time() ?>
                            </a>
                            <a class="c_blue" href="<?php echo Listy_Core_Helper()->get_the_first_taxonomy_link() ?>">
								<?php echo Listy_Core_Helper()->get_the_first_taxonomy() ?>
                            </a>
                        </div>
                        <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute() ?>">
                            <h3 class="__title"><?php echo Listy_Core_Helper()->get_the_title_length( $settings, 'title_length' ) ?></h3>
                        </a>
                        <p><?php echo Listy_Core_Helper()->get_the_excerpt_length( $settings, 'excerpt_length' ) ?></p>
                        <a href="<?php the_permalink(); ?>" class="learn_btn">
							<?php echo esc_html( $settings['read_more_btn'] ) ?>
                            <i class="la la-arrow-right"></i>
                        </a>
                        <div class="media post_author d-flex">
                            <div class="round_img">
								<?php echo Listy_Core_Helper()->get_the_author_avatar() ?>
                            </div>
                            <div class="media-body author_text">
                                <h4><?php echo get_the_author_meta( 'display_name' ) ?></h4>
                                <div class="date"><?php echo get_the_time( get_option( 'date_format' ) ) ?></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			<?php
		}
	endwhile;
	wp_reset_postdata();
	?>
</section>