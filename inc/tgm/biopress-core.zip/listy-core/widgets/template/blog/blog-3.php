<section class="blog-area">
    <div class="row gy-4">
		<?php
		$delay_time = 0.1;
		while ( $posts->have_posts() ) : $posts->the_post();
			?>
            <div class="col-md-6">
                <div class="blog-widget wow fadeInUp bs-sm" data-wow-delay="<?php echo esc_attr( $delay_time ) ?>s">
                    <a href="<?php the_permalink(); ?>">
						<?php the_post_thumbnail( 'listy_510x310' ); ?>
                    </a>
                    <div class="blog-content bg-gray">
                        <p class="blog-text dot-sep">
                            <i class="las la-tag"></i>
							<?php echo Listy_Core_Helper()->get_the_first_taxonomy( 'post_tag' ) ?>
                            <span class="sep"><?php echo Listy_Core_Helper()->get_the_first_taxonomy() ?></span>
                        </p>
                        <a href="<?php the_permalink(); ?>" title="<?php the_title_attribute() ?>">
                            <h5><?php echo Listy_Core_Helper()->get_the_title_length( $settings, 'title_length' ) ?></h5>
                        </a>
                        <div class="blog-sub-text">
							<?php echo Listy_Core_Helper()->get_the_author_avatar( 'user_name', 20 ) ?>
                            <a href="<?php echo get_author_posts_url( get_the_author_meta( 'ID' ) ) ?>">
								<?php echo get_the_author_meta( 'display_name' ) ?>
                            </a>
                            <i class="las la-calendar"></i>
                            <span><?php echo get_the_time( get_option( 'date_format' ) ) ?></span>
                        </div>
                    </div>
                </div>
            </div>
		<?php

		endwhile;
		wp_reset_postdata();
		?>
    </div>
    <nav>
        <ul class="pagination pagi-content">
			<?php
			$big = 999999999; // need an unlikely integer
			echo paginate_links( array(
				'base'      => str_replace( $big, '%#%', esc_url( get_pagenum_link( $big ) ) ),
				'format'    => '?paged=%#%',
				'current'   => max( 1, get_query_var( 'paged' ) ),
				'total'     => $posts->max_num_pages,
				'prev_text' => '<i class="las la-angle-left"></i>Prev',
				'next_text' => 'Next<i class="las la-angle-right"></i>',
			) );
			?>
        </ul>
    </nav>
</section>