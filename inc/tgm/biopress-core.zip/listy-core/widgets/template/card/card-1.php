<div class="li_card_listy">
<div class="li_card">
    <?php 
        if(!empty($settings['sub_title'])) {?>
            <h5 class="li_subtitle"><?php echo esc_html($settings['sub_title']); ?></h5>
        <?php
        }

        if(!empty($settings['title'])) {?>
            <h2 class="li_title"><?php echo esc_html($settings['title']); ?></h2>
        <?php
        }

        if(!empty($settings['button'])) {?>
            <a <?php echo $this->get_render_attribute_string( 'link' ); ?>>
                <h6 class="li_button"><?php echo esc_html($settings['button']); ?></h6>
            </a>
        <?php
        }
    ?>
</div>
</div>