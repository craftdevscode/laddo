<section class="discover-area">
    <div class="discover-contant">
        <?php
        $delay_time = 0.1;
        if ( is_array($locations)) {
            foreach ( $locations as $location ) {
                $meta = get_term_meta($location->term_id, 'listy_listing_city', true); //false returns an array
                $term_image = !empty($meta['city_image']) ? $meta['city_image'] : '';
                $city_link = get_term_link( $location->slug, 'listing_city' );
                ?>
                <div class="discover-item wow fadeInUp " data-wow-delay="<?php echo esc_attr($delay_time) ?> s">
                    <?php
                    if ( !empty($term_image['id']) ) {
                        echo wp_get_attachment_image( $term_image['id'], 'listy_234x234', '', [ 'class' => 'rounded-5' ] );
                    }
                    if ( !is_wp_error($city_link) ) { ?>
                        <a href="<?php echo esc_url($city_link) ?>">
                            <h5 class="small-3 city-title __city_name"><?php echo esc_html($location->name) ?></h5>
                        </a>
                        <?php
                    }
                    if ( !empty($location->count > 0) ) {
                        ?>
                        <p class="small-1 city-text"><?php printf( _n( '%s Listing', '%s Listings', $location->count, 'listy-core' ), $location->count ); ?></p>
                        <?php
                    }
                    ?>
                </div>
                <?php
                $delay_time += 0.1;
            }
        }
        ?>
    </div>
</section>