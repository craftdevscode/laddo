<section class="explore-area wow fadeInUp">
    <ul class="nav nav-pills explore-content mb-30 d-flex flex-wrap bd-highlight" id="pills-tab"
        role="tablist">
		<?php
		if ( ! empty( $locations ) ) {
			foreach ( $locations as $index => $parent_location ) {
				$active        = $index == 0 ? ' active' : '';
				$area_selected = $index == 0 ? 'true' : 'false';
				?>
                <li role="presentation" class="nav-item">
                    <p class="nav-link<?php echo esc_attr( $active ) ?> px-0"
                       id="<?php echo esc_attr( $parent_location->slug ) ?>-tab" data-bs-toggle="pill"
                       data-bs-target="#<?php echo esc_attr( $parent_location->slug ) ?>" role="tab"
                       aria-controls="<?php echo esc_attr( $parent_location->slug ) ?>"
                       aria-selected="<?php echo esc_attr( $area_selected ) ?>">
						<?php echo esc_html( $parent_location->name ) ?>
                    </p>
                </li>
				<?php
			}
		}
		?>
    </ul>
    <div class="tab-content" id="pills-tabContent">
		<?php
		if ( ! empty( $locations ) ) {
			foreach ( $locations as $parent_location ) {
				?>
                <div class="tab-pane fade<?php echo esc_attr( $active ) ?> explore-menu"
                     id="<?php echo esc_attr( $parent_location->slug ) ?>"
                     role="tabpanel"
                     aria-labelledby="<?php echo esc_attr( $parent_location->slug ) ?>-tab">
                    <div class="row">
						<?php
						$args = array(
							'taxonomy'   => 'listing_city',
							'parent'     => $parent_location->term_id,
							'hide_empty' => false,
						);

						$child_locations = get_terms( $args );

						echo '<ul class="explore-item list-unstyled">';
						foreach ( $child_locations as $index => $child_location ) {
							$active = $index == 0 ? ' show active' : '';
							?>
                            <li>
                                <a href="<?php echo get_category_link( $child_location->term_id ) ?>">
									<?php echo esc_html( $child_location->name ) ?>
                                </a>
                            </li>
							<?php
						}
						echo '</ul>';
						?>
                    </div>
                </div>
				<?php
			}
		}
		?>
    </div>
</section>