<div class="row">
	<?php
	if ( is_array($locations)) {
		foreach ( $locations as $location ) {
			$meta = get_term_meta($location->term_id, 'listy_listing_city', true); //false returns an array
			$term_image = !empty($meta['city_image']) ? $meta['city_image'] : '';
            $city_link = get_term_link( $location->slug, 'listing_city' );
			?>
            <div class="col-xl-3 col-lg-4 col-sm-6 wow fadeInUp" data-wow-delay="0.1s">
                <a href="<?php echo esc_url($city_link) ?>" class="cities-feature-widget">
					<?php echo wp_get_attachment_image($term_image['id'], 'listy_550x460', '', [ 'class' => 'city-img'] ) ?>
                    <div class="content">
                        <h4 class="cities-title __city_name"><?php echo esc_html($location->name) ?></h4>
                        <p class="cities-listing"><?php printf( _n( '%s Listing', '%s Listings', $location->count, 'listy-core' ), $location->count ); ?></p>
                    </div>
                </a>
            </div>
			<?php
		}
	}
	?>
</div>