<div class="listing-search-form mt-40 wow fadeInUp" data-wow-delay="0.5s">
    <form action="http://localhost/listy/listing/" class="d-flex text-center wrapper-form">
        <div class="input-group">
            <span class="input-group-text">What?</span>
            <input type="text" id="listy_service_input" name="service_type" value="" class="form-control"
                   placeholder="Ex: food, service, barber, hotel"/>
            <div class="listy_services_list result_dropdown">
				<?php
				$terms = get_terms( array(
					'taxonomy'   => 'listing_cat',
					'hide_empty' => false,
				) );
				if ( ! empty( $terms ) ) {
					foreach ( $terms as $term ) {
						echo '<span>' . esc_html( $term->name ) . '</span>';
					}
				}
				?>
            </div>
        </div>
        <div class="divider"></div>
        <div class="input-group">
            <span class="input-group-text">Where?</span>
            <input type="text" class="form-control geoLocationInp" name="location" value="" placeholder="Your City"/>
            <div class="listy_location_list result_dropdown"></div>
            <span class="input-group-text">
                <a href="#" class="geolocationButton">
                    <img src="./assets/img/icons/icon-01.svg" alt="Icon"/>
                </a>
            </span>
        </div>
        <button class="btn" type="submit">Search</button>
    </form>
</div>