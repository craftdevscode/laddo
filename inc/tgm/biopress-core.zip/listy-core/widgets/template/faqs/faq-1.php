<section class="faq-area p-0">
    <div class="container">
        <div class="row gy-lg-0 gy-4">
            <div class="col-xl-3 col-lg-4 wow fadeInRight">
                <div class="d-flex align-items-start">
                    <div class="nav faq-tag-widget me-3" id="faq-tab" role="tablist" aria-orientation="vertical">
						<?php
						if ( ! empty( $settings['cats'] ) ) {
							foreach ( $settings['cats'] as $index => $cat ) {
								$cat                      = get_term( $cat, 'faq_cat' );
								$tab_count                = $index + 1;
								$active                   = $tab_count == 1 ? ' active' : '';
								$tab_category_setting_key = $this->get_repeater_setting_key( 'tab_li', '', $index );

								$this->add_render_attribute( $tab_category_setting_key, [
									'class'          => [ 'nav-link', $active ],
									'id'             => $cat->slug . '-tab',
									'data-bs-toggle' => 'pill',
									'data-bs-target' => '#' . $cat->slug,
									'type'           => 'button',
									'role'           => 'tab',
									'aria-controls'  => $cat->slug,
									'aria-selected'  => $tab_count == 1 ? 'true' : 'false',
								] );

								if ( ! empty( $cat->name ) ) { ?>
                                    <button <?php echo $this->get_render_attribute_string( $tab_category_setting_key ); ?>>
										<?php echo esc_html( $cat->name ) ?>
                                    </button>
									<?php
								}
							}
						}
						?>
                    </div>
                </div>
            </div>

            <div class="col-xl-9 col-lg-8 wow fadeInLeft">
                <div class="tab-content" id="faq-tabContent">
					<?php
					if ( ! empty( $settings['cats'] ) ) {
						foreach ( $settings['cats'] as $index => $cat ) {
							$cat                     = get_term( $cat, 'faq_cat' );
							$tab_count               = $index + 1;
							$tab_content_setting_key = $this->get_repeater_setting_key( 'tab_content', '', $index );
							$active                  = $tab_count == 1 ? ' show active' : '';
							$this->add_render_attribute( $tab_content_setting_key, [
								'class'           => [ 'tab-pane fade', $active ],
								'id'              => $cat->slug,
								'role'            => 'tabpanel',
								'aria-labelledby' => $cat->slug . '-tab',
							] );
							?>
                            <div <?php echo $this->get_render_attribute_string( $tab_content_setting_key ); ?>>
                                <div class="faq-list">
									<?php
									$faqs       = new WP_Query( array(
										'post_type'      => 'faq',
										'posts_per_page' => - 1,
										'order'          => $settings['order'],
										'orderby'        => $settings['orderby'],
										'tax_query'      => array(
											array(
												'taxonomy' => 'faq_cat',
												'field'    => 'slug',
												'terms'    => $cat->slug,
											),
										),
									) );
									$delay_time = 0.0;
									while ( $faqs->have_posts() ) : $faqs->the_post();
										?>
                                        <div class="single-faq">
                                            <h5 class="_title"><?php the_title(); ?></h5>
											<?php the_content() ?>
                                        </div>
										<?php
										$delay_time += 0.1;
									endwhile;
									wp_reset_postdata();
									?>
                                </div>
                            </div>
							<?php
						}
					}
					?>
                </div>
            </div>
        </div>
    </div>
</section>