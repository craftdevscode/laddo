<?php
$servicesType   = !empty($_GET['service_type']) ? sanitize_text_field($_GET['service_type']) : '';
$location       = !empty($_GET['location']) ? sanitize_text_field($_GET['location']) : '';
?>
<section class="listing-page-area bg-gray">
    <div class="container-fluid pe-lg-0">
        <div class="row">
            <div class="col-xxl-7 col-xl-8">
                <div class="pages-contant">
                    <form class="inventory_filter_form" method="post" action="">
                        <div class="d-flex flex-sm-row flex-column mb-20">

                            <div class="listing-search-pages">
                                <form action="#">
                                    <div class="d-flex text-center">
                                        <div class="input-group pr-15">
                                            <input type="text" id="listy_service_input" name="service_type" value="<?php echo esc_attr($servicesType) ?>" class="form-control ps-0" placeholder="What are you looking for?">
                                            <div class="listy_services_list result_dropdown">
                                                <?php
                                                $terms = get_terms(array(
                                                    'taxonomy'   => 'listing_cat',
                                                    'hide_empty' => false,
                                                ));
                                                if (!empty($terms)) {
                                                    foreach ($terms as $term) {
                                                        echo '<span>' . esc_html($term->name) . '</span>';
                                                    }
                                                }
                                                ?>
                                            </div>
                                        </div>
                                        <div class="divider"></div>
                                        <div class="input-group">
                                            <a class="input-search" href="#"><i class="las la-map-marked-alt"></i></a>
                                            <input type="text" class="form-control geoLocationInp ps-0" name="location" value="<?php echo esc_attr($location) ?>" placeholder="Your City" />
                                            <div class="listy_location_list result_dropdown"></div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>


                        <div class="pages-btn d-flex flex-wrap pb-30">
                            <div class="l-btn form-check d-flex">

                                <div class="open_time">
                                    <?php $user_local_time = date_i18n('H:i', current_time('timestamp')); ?>
                                    <input type="checkbox" class="btn-check" id="btnCheck03" value="<?php echo esc_attr($user_local_time) ?>">
                                    <label class="btn btn-outline-secondary" for="btnCheck03"> <i class="las la-clock"></i> Open now</label>
                                </div>

                            </div>
                            <div class="r-btn">
                                <a class="small-2 p-btn" href="#"> <i class="las la-redo-alt"></i> Reset All</a>
                            </div>
                        </div>


                        <div class="pages-sub-title d-flex flex-wrap justify-content-between pt-30 mb-40">
                            <p class="sub-regular-1 mb-10"><span class="number_of_posts"></span> Results Found</p>
                            <div class="left-contant d-flex flex-wrap">
                                <select name="orderby" class="custom-select small-1 db-toggle listing_shorter">
                                    <option value="menu_order" selected="selected">Default sorting</option>
                                    <option value="date">Latest</option>
                                    <option value="popularity">Most Popular</option>
                                    <option value="price">Price: low to high</option>
                                    <option value="price-desc">Price: high to low</option>
                                </select>
                                <div class="gl-btn">
                                    <a class="grid-btn active text-center" href="#"><i class="las la-border-all"></i></a>
                                    <a class="list-btn text-center" href="#"><i class="las la-list-ul"></i></a>
                                </div>
                            </div>
                        </div>
                    </form>
                    <!--Restaurants item -->
                    <?php

                    $args = [
                        'post_type'     => 'listing',
                        'post_status'   => 'publish',
                        'posts_per_page' => $show_count,

                    ];
                    $listing_posts = new \WP_Query($args);
                    $max_number = !empty($listing_posts->max_num_pages) ? $listing_posts->max_num_pages : '0';
                    ?>
                    <div class="pages-items mb-10">
                        <div class="row listing_post_loader" data-per_page="<?php echo esc_attr($show_count) ?>" data-order="1" data-max_page="<?php echo esc_attr($max_number) ?>">

                        </div>
                    </div>
                    <!-- Restaurants item-->
                    <nav class="pagination_nav" aria-label="...">
                        <ul class="pagination pagi-content">

                            <button class="pagination_item prev_page" data-paged="1"><i class=" las la-angle-left"></i>Prev</button>

                            <?php
                            if (!empty($listing_posts)) {
                                for ($i = 1; $max_number >= $i; $i++) {
                                    $active = $i == 1 ? 'active' : '';
                                    echo '<button class="pagination_item page-link ' . esc_attr($active) . '" data-paged="' . esc_attr($i) . '">' . $i . '</button>';
                                }
                            } ?>

                            <button class="pagination_item next_page" data-paged="1">Next <i class=" las la-angle-right"></i></button>

                        </ul>
                    </nav>
                </div>
            </div>
            <!--Google map-->
            <div id="map" class="pages-map px-0 col-xxl-5 col-xl-4 z-depth-1-half map-container wow fadeIn" style="height: 900px"></div>
            <!--Google Maps-->
        </div>
    </div>
</section>