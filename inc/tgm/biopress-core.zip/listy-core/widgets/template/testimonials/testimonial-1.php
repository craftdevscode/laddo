<div class="client-area wow fadeInUp">
    <div class="row">
        <div class="col-12">
            <div class="client-main-slider">
				<?php
				if ( !empty($testimonials) ) {
					foreach ( $testimonials as $item ) {
						?>
                        <div class="single-slider pt-0">
                            <div class="row">
                                <div class="col-lg-6 text-center">
                                    <div class="client-image">
										<?php
										if ( !empty( $item['author_img']['id']) ) {
											echo wp_get_attachment_image($item['author_img']['id'], 'full', '', array( 'class' => 'main-img' ));
										}
										if ( !empty( $item['author_shape']['id']) ) {
											echo wp_get_attachment_image($item['author_shape']['id'], 'full', '', array( 'class' => 'shape' ));
										}
										?>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="slider-content">
										<?php
										if ( !empty($item['review_content']) ) { ?>
                                            <p class="client-quote __content"><?php echo esc_html($item['review_content']) ?></p>
											<?php
										}
										if ( !empty($item['name']) ) { ?>
                                            <p class="client-name __name"><?php echo esc_html($item['name']) ?></p>
											<?php
										}
										if ( !empty($item['designation']) ) { ?>
                                            <p class="job-title __designation"><?php echo esc_html($item['designation']) ?></p>
											<?php
										}
										?>
                                    </div>
                                </div>
                            </div>
                        </div>
						<?php
					}
				}
				?>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12">
            <div class="client-thumb-slider">
			    <?php
			    $i = 0;
			    $slide_i = 1;
			    if ( !empty($testimonials) ) {
				    foreach ( $testimonials as $item ) {
					    ?>
                        <div class="single-thumb __name">
						    <?php echo esc_html($item['name']) ?>
                        </div>
					    <?php
				    }
			    }
			    ?>
            </div>
        </div>
    </div>
</div>