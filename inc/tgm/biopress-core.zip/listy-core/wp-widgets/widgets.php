<?php
// Require widget files
require plugin_dir_path( __FILE__ ) . 'class-widget-job-categories.php';
require plugin_dir_path( __FILE__ ) . 'class-widget-job-locations.php';
require plugin_dir_path( __FILE__ ) . 'class-widget-job-schedule.php';
require plugin_dir_path( __FILE__ ) . 'class-widget-job-search-form.php';
//require plugin_dir_path(__FILE__) . 'class-widget-recent-post.php';

// Register Widgets
add_action( 'widgets_init', function () {
	register_widget( 'ListyCore\WpWidgets\Widget_Job_Categories' );
	register_widget( 'ListyCore\WpWidgets\Widget_Job_locations' );
	register_widget( 'ListyCore\WpWidgets\Widget_Job_Schedule' );
	register_widget( 'ListyCore\WpWidgets\Widget_Job_Search_Form' );
	//register_widget( 'ListyCore\WpWidgets\Widget_Recent_Posts');
} );