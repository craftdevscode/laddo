<?php

namespace ListyCore\WpWidgets;

use WP_Widget;

/**
 * Widget API: Listy_Widget_Categories class
 *
 * @package WordPress
 * @subpackage Widgets
 * @since 4.4.0
 */

/**
 * Core class used to implement a Categories widget.
 *
 * @since 2.8.0
 *
 * @see WP_Widget
 */
class Widget_Job_Schedule extends WP_Widget {

	/**
	 * Sets up a new Categories widget instance.
	 *
	 * @since 2.8.0
	 */
	public function __construct() {
		$widget_ops = array(
			'classname'                   => '',
			'description'                 => __( 'A Radio Button of Job Offers' ),
			'customize_selective_refresh' => true,
		);
		parent::__construct( 'widgets_job_schedule', esc_html__( 'Job Schedule', 'listy-core' ), $widget_ops );

	}

	/**
	 * Outputs the content for the current Categories widget instance.
	 *
	 * @param array $args Display arguments including 'before_title', 'after_title',
	 *                        'before_widget', and 'after_widget'.
	 * @param array $instance Settings for the current Categories widget instance.
	 *
	 * @since 2.8.0
	 * @since 4.2.0 Creates a unique HTML ID for the `<select>` element
	 *              if more than one instance is displayed on the page.
	 *
	 */
	public function widget( $args, $instance ) {

		$default_title = __( 'Job Schedule' );
		$title         = ! empty( $instance['title'] ) ? $instance['title'] : $default_title;

		/** This filter is documented in wp-includes/widgets/class-wp-widget-pages.php */
		$title = apply_filters( 'widget_title', $title, $instance, $this->id_base );

		echo $args['before_widget'];

		if ( $title ) {
			echo $args['before_title'] . $title . $args['after_title'];
		}

		?>

        <div class="widget-content mt-20">
			<?php
			$job_type_args = array(
				'taxonomy' => 'job_type',
			);
			$job_types     = get_categories( $job_type_args );
			foreach ( $job_types as $job_type ) {
				$id = wp_unique_id( 'job_type' );
				?>
                <a href="<?php echo get_category_link( $job_type->term_id ) ?>"
                   class="form-check form-check-inline mr-30">
                    <input class="form-check-input" type="radio" name="inlineRadioOptions"
                           id="<?php echo esc_attr( $id ) ?>" value="<?php echo esc_attr( $id ) ?>">
                    <label class="form-check-label" for="<?php echo esc_attr( $id ) ?>">
						<?php echo esc_html( $job_type->name ) ?>
                    </label>
                </a>
				<?php
			}

			?>
        </div>

		<?php

		echo $args['after_widget'];
	}

	/**
	 * Handles updating settings for the current Categories' widget instance.
	 *
	 * @param array $new_instance New settings for this instance as input by the user via
	 *                            WP_Widget::form().
	 * @param array $old_instance Old settings for this instance.
	 *
	 * @return array Updated settings to save.
	 * @since 2.8.0
	 *
	 */
	public function update( $new_instance, $old_instance ) {
		$instance                   = $old_instance;
		$instance['title']          = sanitize_text_field( $new_instance['title'] );
		$instance['count']          = ! empty( $new_instance['count'] ) ? 1 : 0;
		$instance['hierarchical']   = ! empty( $new_instance['hierarchical'] ) ? 1 : 0;
		$instance['dropdown']       = ! empty( $new_instance['dropdown'] ) ? 1 : 0;
		$instance['cats_num_listy'] = sanitize_text_field( $new_instance['cats_num_listy'] );

		return $instance;
	}

	/**
	 * Outputs the settings form for the Categories widget.
	 *
	 * @param array $instance Current settings.
	 *
	 * @since 2.8.0
	 *
	 */
	public function form( $instance ) {

		// Defaults.
		$instance = wp_parse_args( (array) $instance, array( 'title' => '' ) );
		?>
        <p>
            <label for="<?php echo $this->get_field_id( 'title' ); ?>"><?php _e( 'Title:' ); ?></label>
            <input class="widefat" id="<?php echo $this->get_field_id( 'title' ); ?>"
                   name="<?php echo $this->get_field_name( 'title' ); ?>" type="text"
                   value="<?php echo esc_attr( $instance['title'] ); ?>"/>
        </p>
		<?php
	}

}
