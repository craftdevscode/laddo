<?php

namespace ListyCore\WpWidgets;

use WP_Widget;
use WP_Query;

/**
 * Widget API: Listy_Widget_Categories class
 *
 * @package WordPress
 * @subpackage Widgets
 * @since 4.4.0
 */

/**
 * Core class used to implement a Categories widget.
 *
 * @since 2.8.0
 *
 * @see WP_Widget
 */
class Widget_Job_locations extends WP_Widget {

	/**
	 * Sets up a new Categories widget instance.
	 *
	 * @since 2.8.0
	 */
	public function __construct() {
		$widget_ops = array(
			'classname'                   => '',
			'description'                 => __( 'A list or dropdown of Job locations.' ),
			'customize_selective_refresh' => true,
		);
		parent::__construct( 'widgets_job_locations', esc_html__( 'Job Locations', 'listy-core' ), $widget_ops );

	}

	/**
	 * Outputs the content for the current Categories widget instance.
	 *
	 * @param array $args Display arguments including 'before_title', 'after_title',
	 *                        'before_widget', and 'after_widget'.
	 * @param array $instance Settings for the current Categories widget instance.
	 *
	 * @since 2.8.0
	 * @since 4.2.0 Creates a unique HTML ID for the `<select>` element
	 *              if more than one instance is displayed on the page.
	 *
	 */
	public function widget( $args, $instance ) {

		echo $args['before_widget'];

		?>
        <div class="select-location">
            <form action="<?php echo esc_url( home_url( '/' ) ) ?>" method="get">
                <span class="arrow-icon"><i class="las la-angle-down"></i></span>
                <select id="locationSelect" class="form-control es-input">
					<?php
					$location_args = array(
						'taxonomy'         => 'job_location',
						'orderby'          => 'name',
						'show_option_none' => __( 'Select Location', 'listy-core' ),
					);

					$locations = get_terms( $location_args );
					echo '<option value="Select Location" selected>' . esc_html__( 'Select Location', 'listy-core' ) . '</option>';
					foreach ( $locations as $location ) {
						?>
                        <option value="<?php echo get_category_link( $location->term_id ) ?>"><?php echo esc_html( $location->name ) ?></option>
						<?php
					}
					?>
                </select>
            </form>
        </div>

        <script>
            document.getElementById("locationSelect").onchange = function () {
                if (this.selectedIndex !== 0) {
                    window.location.href = this.value;
                }
            };
        </script>
		<?php

		echo $args['after_widget'];
	}

	/**
	 * Handles updating settings for the current Categories' widget instance.
	 *
	 * @param array $new_instance New settings for this instance as input by the user via
	 *                            WP_Widget::form().
	 * @param array $old_instance Old settings for this instance.
	 *
	 * @return array Updated settings to save.
	 * @since 2.8.0
	 *
	 */
	public function update( $new_instance, $old_instance ) {
		$instance = $old_instance;

		return $instance;
	}

	/**
	 * Outputs the settings form for the Categories widget.
	 *
	 * @param array $instance Current settings.
	 *
	 * @since 2.8.0
	 *
	 */
	public function form( $instance ) {

		//
	}

}
