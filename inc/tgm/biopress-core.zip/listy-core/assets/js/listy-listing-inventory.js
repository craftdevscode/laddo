;(function($){
    "use strict";

    $(document).ready(function () {

        // Initialize the map
        var postLoader = document.querySelector(".listing_post_loader");

        if (postLoader != null) {
            listy_inventory();
        }

        let openTime = $('.open_time .btn-outline-secondary');
        openTime.on('click', function () {
            $(this).toggleClass('active');
            if( $(this).hasClass('active') ) {
                let currentTime = $('#btnCheck03').val();
                listy_inventory('', '', currentTime);
            }
            else{
                listy_inventory();
            }
        });

        
        let paged_items = $('.pagination .page-link');
        let prev_page = $('.prev_page');
        let next_page = $('.next_page');
        prev_page.hide();

        // Previous page =====
        prev_page.on('click', function (e) {
            let current_page = $('.page-link.active').attr('data-paged');
            let prev_page_ = $(this).attr('data-paged');
            let prevPaged = parseInt(current_page) - parseInt(prev_page_);
            
            let pagination_item = document.querySelectorAll('.page-link');
            pagination_item.forEach(function (e, idx, array){
                
                e.classList.remove('active');
                if (e.getAttribute('data-paged') == prevPaged){
                    e.classList.add('active');
                }
                if (idx === 0 && e.classList.contains('active')) {
                    prev_page.hide();
                }
                                                 
            });
            listy_inventory('', '', '', prevPaged);
            next_page.show();
        });
        
        // Next page =====================
        next_page.on('click', function (e) {
            prev_page.show();
            let current_page = $('.page-link.active').attr('data-paged');
            let next_page_ = $(this).attr('data-paged');
            let nextpaged = parseInt(current_page) + parseInt(next_page_);
            
            let pagination_item = document.querySelectorAll('.page-link');
            pagination_item.forEach(function (e, idx, array){
                
                e.classList.remove('active');
                if (e.getAttribute('data-paged') == nextpaged){
                    e.classList.add('active');
                }
                if (idx === array.length - 1 && e.classList.contains('active')) {
                    next_page.hide();
                }
                                                 
            });
            listy_inventory('', '', '', nextpaged);
        });
        
        paged_items.on('click', function () {
            paged_items.removeClass('active');
            $(this).hasClass('page-link') ? $(this).addClass('active') : '';
            let $max_page = postLoader.getAttribute('data-max_page');
            let $paged = $(this).attr('data-paged');
            $paged == '1' ? prev_page.hide() : prev_page.show();
            $paged == $max_page ? next_page.hide() : next_page.show();
                      
            $(this).on('click', listy_inventory('', '', '', $(this).attr('data-paged')) );
        });

        function listy_inventory( service_type_ = '', location_ = '', current_time = '', paged = '') {
            let loaderClass = document.querySelector(".listing_post_loader");
            var queryString = window.location.search;
            var urlParams = new URLSearchParams(queryString);
            // Access individual query parameters
            var st_from_link = urlParams.get('service_type') != null ? urlParams.get('service_type') : '';
            var lo_from_link = urlParams.get('location') != null ? urlParams.get('location') : '';

            let serviceType   = service_type_ != '' ? service_type_ : st_from_link;
            let locationValue = location_ != '' ? location_ : lo_from_link;
            let currentTime   = current_time != '' ? current_time : '';
            let postPerPage   = postLoader.getAttribute("data-per_page");
            let order         = postLoader.getAttribute("data-order");
            let paged_        = paged != '' ? paged : 1;
            
            let $settings = 'per_page=' + postPerPage + '&order=' + paged_ + '&service_type=' + serviceType + '&location=' + locationValue + '&current_time=' + currentTime;

            $.ajax({
                type: "post",
                url: inventory_listing.ajax_url + "?action=listing_inventory",
                data: $settings,
                dataType: "JSON",
                beforeSend: function(){
                    loaderClass.textContent = '';
                },
                success: function (res) {
                    var markerData = (res.data.posts) ? res.data.posts : [];
                    let found_posts = document.querySelector('.number_of_posts');
                    found_posts.textContent = res.data.posts.length != '' ? res.data.posts.length : 'No';
                    console.log(res);
                    // listing post
                    if (markerData != ''){
                        markerData.forEach(function (listingPost) {
                            let column = document.createElement("div");
                            column.setAttribute("class", "col-lg-4 col-sm-6");
                            column.innerHTML ='<div class="restaurant-listing-widget wow fadeInUp">' +
                                                '<div class="restaurant-img">' +
                                                    '<div class="bottom-caption">' +
                                                        '<p><span><i class="lar la-clock"></i> ' + listingPost.open_close +'</span> ⋅ ' + listingPost.open_close_time +'</p>' +
                                                    '</div>' +
                                                    '<img src="' + listingPost.thumb+'" alt="' + listingPost.title +'">' +
                                                '</div>' +
                                                '<div class= "contant bg-white" > ' +
                                                    '<a href = "'+listingPost.permalink+'" ><h4 class= "sub-bold-2 mb-20">' + listingPost.title +'</h4></a>' +
                                                    '<div class="reviews d-flex mb-10">' +
                                                        '<span>4.8 <i class="las la-star"></i><i class="las la-star"></i><i class="las la-star"></i><i class="las la-star"></i><i class="las la-star"></i>50 reviews</span>' +
                                                        '<span class="d-flex dot-sep">'+listingPost.currency+'</span>' +
                                                    '</div>' +
                                                    '<span class="restaurants-author d-flex"><i class="las la-map-marker"></i> ' + listingPost.address +'</span>' +
                                                    '<div class="s-btn d-flex">' +
                                                        '<a href="' + listingPost.website +'"><i class="las la-globe"></i>Website</a>' +
                                                        '<a href="tel:' + listingPost.phone +'"><i class="las la-phone-volume"></i>Call</a>' +
                                                        '<a href="#"><i class="las la-bookmark"></i>Save</a>' +
                                                    '</div>' +
                                                '</div>' +
                                            '</div>';
                            loaderClass.appendChild(column);
                        });

                        var centerLatLng = {
                            lat: markerData[0]['position']['lat'],
                            lng: markerData[0]['position']['lng']
                        };

                        // Create a new map instance
                        var map = new google.maps.Map(document.getElementById('map'), {
                            zoom: 16,
                            center: centerLatLng
                        });

                        // Create and display markers
                        markerData.forEach(function (item) {

                            var marker = new google.maps.Marker({
                                position: item.position,
                                map: map,
                                title: item.title,
                                icon: 'http://localhost/listy/wp-content/themes/listy/assets/img/location-pin.png'
                            });

                            var contentStr = '<div class="restaurant-listing-widget wow fadeInUp mb-0">' +
                                                '<div class="restaurant-img">' +
                                                    '<div class="bottom-caption">' +
                                                        '<p><span><i class="lar la-clock"></i> ' + item.open_close +'</span> ⋅ ' + item.open_close_time +'</p>' +
                                                    '</div>' +
                                                    '<img src="' + item.thumb+'" alt="' + item.title +'">' +
                                                '</div>' +
                                                '<div class= "contant bg-white" > ' +
                                                    '<a href = "'+item.permalink+'" ><h4 class= "sub-bold-2 mb-20">' + item.title +'</h4></a>' +
                                                    '<div class="reviews d-flex mb-10">' +
                                                        '<span>4.8 <i class="las la-star"></i><i class="las la-star"></i><i class="las la-star"></i><i class="las la-star"></i><i class="las la-star"></i>50 reviews</span>' +
                                                        '<span class="d-flex dot-sep">'+item.currency+'</span>' +
                                                    '</div>' +
                                                    '<span class="restaurants-author d-flex"><i class="las la-map-marker"></i> ' + item.address +'</span>' +
                                                    '<div class="s-btn d-flex">' +
                                                        '<a href="' + item.website +'"><i class="las la-globe"></i>Website</a>' +
                                                        '<a href="tel:' + item.phone +'"><i class="las la-phone-volume"></i>Call</a>' +
                                                        '<a href="#"><i class="las la-bookmark"></i>Save</a>' +
                                                    '</div>' +
                                                '</div>' +
                                            '</div>';

                            var infowindow = new google.maps.InfoWindow({
                                position: item.position,
                                content: contentStr,
                                ariaLabel: item.position,
                            });
                            marker.addListener("click", () => {
                                infowindow.open({
                                    anchor: marker,
                                    map,
                                });
                                infowindow.close
                            });
                        });
                    }
                    
                },
                error: function (res) {
                    console.log(res);
                },
                complete: function () {
                    
                },
            });
        }


        // Advance Search ==========================
        let serviceInput    = document.querySelector('#listy_service_input');
        let locationInput   = document.querySelector('.geoLocationInp');
        let servicesList    = document.querySelector('.listy_services_list');
        let serviceList_    = $('.listy_services_list');
        let servicesSpan    = $('.listy_services_list span');

        if( serviceInput != null ){
            serviceInput.addEventListener('keyup', (event) => {
                locationInput.value = '';
                servicesList.style.display = 'flex';
                
                var inputVal = serviceInput.value.toLowerCase();
                servicesSpan.hide();
                servicesSpan.each(function () {
                    var text = $(this).text().toLowerCase();
                    if (text.indexOf(inputVal) != -1) {
                        $(this).show();
                    }
                });
                
                $(document).on("mouseup", function (e) {
                    if (!serviceList_.is(e.target) && serviceList_.has(e.target).length === 0) {
                        serviceList_.hide();
                    }
                });            
            });
        }

        let listclass = $('.listy_services_list span');
        listclass.each(function () {
            jQuery(this).on("click", function (e) {
                e.preventDefault();

                var value = jQuery(this).text().toLowerCase();
                jQuery(this).parents(".input-group").find("input").val(value);

                // pass location value to
                let locationList = document.querySelector('.listy_location_list');
                let serviceList__ = $('.listy_services_list');

                $.ajax({
                    type: "post",
                    url: inventory_listing.ajax_url + "?action=advance_search",
                    data: 'location=' + value,
                    dataType: "JSON",
                    success: function (res) {
                        if (res.success) {
                            let locations = res.data.location;
                            locations.forEach(element => {
                                let locationListSpan = document.createElement('span');
                                locationListSpan.innerHTML = element;

                                locationList.appendChild(locationListSpan);
                            });
                        }

                    },
                    error: function (res) {
                        console.log(res);
                    },
                    complete: function () {
                        
                        locationInput.addEventListener('keyup', function (e) {
                            locationList.style.display = 'flex';
                        });

                        let locationList_ = $('.listy_location_list');
                        $(document).on("mouseup", function (e) {
                            if (!locationList_.is(e.target) && locationList_.has(e.target).length === 0) {
                                locationList_.hide();

                            }
                        });
                        let locationClass = $('.listy_location_list span');
                        locationClass.each(function () {
                            jQuery(this).on("click", function () {
                                var locationValue = jQuery(this).text().toLowerCase();
                                jQuery(this).parents(".input-group").find("input").val(locationValue);
                                
                                if (postLoader != null) {
                                    listy_inventory(value, locationValue);
                                }

                                $(this).parents('.listy_location_list').hide();
                                
                            });
                        });
                        
                        locationInput.addEventListener('keyup', function (e) {
                            var val = $(this).val().toLowerCase();
                            locationClass.hide();

                            locationClass.each(function () {
                                var text = $(this).text().toLowerCase();
                                if (text.indexOf(val) != -1) {
                                    $(this).show();
                                }
                            });
                        });

                    },
                });

                if (postLoader != null){
                    listy_inventory( value );
                }

                serviceList__.hide();

            });
        });

        

    });


})(jQuery);