;(function ($, elementor) {
    "use strict";
    var $window = $(elementor);

    var listyCore = {
        onInit: function () {
            var E_FRONT = elementorFrontend;
            var widgetHandlersMap = {
                "listy_listing.default": listyCore.listingHandler,
                "listy_testimonials.default": listyCore.TestimonialsHandler,
                "listy_video.default": listyCore.video,
                "listy_timeline_carousel.default": listyCore.timelineCarousel,
                "listy_pricing_table_switcher.default": listyCore.pricingSwitcher,
                "listy_mailchimp.default": listyCore.mailchimp,
            };

            $.each(widgetHandlersMap, function (widgetName, callback) {
                E_FRONT.hooks.addAction("frontend/element_ready/" + widgetName, callback);
            });

        },


        //** === Mailchimp Handler === **//
        mailchimp: function ($scope) {

            let mailchimpContainer = $scope.find(".mailchimp");
            let dataUrl = mailchimpContainer.data('action-url');
            let meMail = mailchimpContainer.find(".memail");
            let errorMsg = mailchimpContainer.find(".mchimp-errmessage");
            let successMsg = mailchimpContainer.find(".mchimp-sucmessage");

            if (mailchimpContainer.length > 0) {
                mailchimpContainer.ajaxChimp({
                    callback: mailchimpCallback,
                    url: dataUrl,
                });
                meMail.on("focus", function () {
                    errorMsg.fadeOut();
                    successMsg.fadeOut();
                });
                meMail.on("keydown", function () {
                    errorMsg.fadeOut();
                    successMsg.fadeOut();
                });
                meMail.on("click", function () {
                    meMail.val("");
                });

                function mailchimpCallback(resp) {
                    if (resp.result === "success") {
                        errorMsg.html(resp.msg).fadeIn(1000);
                        successMsg.fadeOut(500);
                    } else if (resp.result === "error") {
                        errorMsg.html(resp.msg).fadeIn(1000);
                    }
                }
            }

        },


        //** === Pricing Switcher === **//
        pricingSwitcher: function ($scope) {

            // Pricing monthly
            let monthlyTab = $scope.find(".pricing-switcher-2 .nav-link");
            if (monthlyTab.length > 0) {
                monthlyTab.on("click", function () {
                    if ($("#monthly-tab").hasClass("active")) {
                        $(".switcher-bg").removeClass("right");
                    } else {
                        $(".switcher-bg").addClass("right");
                    }
                });
            }

            // Pricing annual
            let yearlyTab = $scope.find('.day-switcher .nav-link');
            if (yearlyTab.length > 0) {
                yearlyTab.on("click", function () {
                    if ($("#annual-tab").hasClass("active")) {
                        $(".day-switcher").removeClass("right");
                    } else {
                        $(".day-switcher").addClass("right");
                    }
                });
            }

        },


        //** === Timeline Carousel === **//
        timelineCarousel: function ($scope) {

            if ($(".history-wrapper").length) {
                var $carousel = $(".history-wrapper");
                var $slider;
                $carousel
                    .slick({
                        speed: 300,
                        arrows: false,
                        infinite: false,
                        loop: false,
                        slidesToShow: 3,
                        responsive: [
                            {
                                breakpoint: 800,
                                settings: {
                                    slidesToShow: 2,
                                    slidesToScroll: 1,
                                },
                            },
                            {
                                breakpoint: 480,
                                settings: {
                                    slidesToShow: 1,
                                    slidesToScroll: 1,
                                },
                            },
                        ],
                    })
                    .on("afterChange", (e, slick, slide) => {
                        $slider.slider("value", slide);
                    });

                $slider = $(".history-scrollbar").slider({
                    min: 0,
                    max: 7,
                    slide: function (event, ui) {
                        var slick = $carousel.slick("getSlick"),
                            goTo = (ui.value * (slick.slideCount - 1)) / 7;

                        $carousel.slick("goTo", goTo);
                    },
                });
            }

        },

        //** === Video js === **//
        video: function ($scope) {
            // get video source from data-src button
            var $videoSrc;
            $(".video-btn").click(function () {
                $videoSrc = $(this).data("src");
            });

            // autoplay video on modal load
            $("#myModal").on("shown.bs.modal", function (e) {
                // youtube iframe configuration and settings
                $("#video").attr(
                    "src",
                    $videoSrc + "?autoplay=1&rel=0&controls=1&loop=1&modestbranding=1"
                );
            });
            // stop playing the youtube video when modal closed
            $("#myModal").on("hide.bs.modal", function (e) {
                // stop video
                $("#video").attr("src", $videoSrc);
            });

        },

        //** === Testimonials Handler === **//
        TestimonialsHandler: function ($scope) {

            let slider = $scope.find('.client-main-slider');

            if (slider.length > 0) {
                slider.slick({
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    arrows: true,
                    prevArrow:
                        '<button type="button" class="slick-prev"><i class="las la-arrow-left"></i></button>',
                    nextArrow:
                        '<button type="button" class="slick-next"><i class="las la-arrow-right"></i></button>',

                    asNavFor: ".client-thumb-slider",
                    centerMode: false,
                });
                $(".client-thumb-slider").slick({
                    slidesToShow: 6,
                    asNavFor: ".client-main-slider",
                    dots: false,
                    centerMode: false,
                    focusOnSelect: true,
                    responsive: [
                        {
                            breakpoint: 992,
                            settings: {
                                slidesToShow: 4,
                                slidesToScroll: 1,
                                centerMode: true,
                                centerPadding: "0px",
                            },
                        },
                        {
                            breakpoint: 768,
                            settings: {
                                slidesToShow: 3,
                                slidesToScroll: 1,
                            },
                        },
                        {
                            breakpoint: 475,
                            settings: {
                                slidesToShow: 2,
                                slidesToScroll: 1,
                            },
                        },
                    ],
                });

            }
        },


        //======================== Pricing Table Tabs =========================== //
        listingHandler: function ($scope) {

            //============= Currency Changes
            let slider = $scope.find('.exclusive-slider');

            if (slider.length) {
                slider.slick({
                    autoplay: true,
                    slidesToScroll: 1,
                    slidesToShow: 1,
                    arrows: true,
                    dots: false,
                    asNavFor: ".exclusive-slider-thumbnails",
                });
            }
            if ($(".exclusive-slider-thumbnails").length) {
                $(".exclusive-slider-thumbnails").slick({
                    autoplay: true,
                    slidesToShow: 4,
                    // slidesToScroll: 1,
                    asNavFor: ".exclusive-slider",
                    dots: false,
                    focusOnSelect: true,
                    variableWidth: true,
                });
            }

            // Remove active class from all thumbnail slides
            $(".exclusive-slider-thumbnails .slick-slide").removeClass("slick-active");

            // Set active class to first thumbnail slides
            $(".exclusive-slider-thumbnails .slick-slide")
                .eq(0)
                .addClass("slick-active");

            // On before slide change match active thumbnail to current slide
            slider.on(
                "beforeChange",
                function (event, slick, currentSlide, nextSlide) {
                    let mySlideNumber = nextSlide;
                    $(".exclusive-slider-thumbnails .slick-slide").removeClass(
                        "slick-active"
                    );
                    $(".exclusive-slider-thumbnails .slick-slide")
                        .eq(mySlideNumber)
                        .addClass("slick-active");
                }
            );


        },


    }

    $window.on("elementor/frontend/init", listyCore.onInit);

})(jQuery, window);